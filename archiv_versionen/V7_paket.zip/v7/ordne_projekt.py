"""
ordne_projekt.py
----------------
Räumt den Projektordner auf (einmalig) und spielt die neuen Dateien aus diesem Paket ein.

Zielstruktur:
  app.py, admin_app.py, README.md, requirements.txt, .gitignore
  lernassistent/        Bibliothek (rag_pipeline, wissensgraph, reranker, ideen_feedback, pdf_struktur, ...)
  skripte/wissensbasis/ Wissensbasis bauen, Chunks zuordnen, Pilot
  skripte/evaluation/   Testläufe, RAGAS, Vergleiche, Archiv
  skripte/diagnose/     Einzelfrage-Analysen (frage_testen, graph_erklaeren, retrieval_erklaeren)
  skripte/setup/        Umgebungsprüfung
  skripte/laeufe/       Lauf-Skripte (Nachtlauf)
  daten/quellen/        PDFs                      (nicht ins Git)
  daten/wissensbasen/   knowledge_base_*.json      (nicht ins Git)
  daten/extraktion/     MinerU-Ausgaben, Bilder    (nicht ins Git)
  daten/testfragen/     Testfragen, Testideen
  evaluationsdaten/     Logs, Ergebnisse, archiv/  (unverändert)
  cache/                BM25-/Graph-Cache          (unverändert)
  protokolle/           Konsolenausgaben, Pilotseiten
  doku/                 Dokumentation
  alt/                  alte Pakete und Dateien

Was das Skript tut:
  1. verschiebt bekannte Dateien (git mv, wenn von Git verfolgt, sonst normal verschieben),
  2. kopiert die neuen/aktualisierten Dateien aus dem Ordner neu/ dieses Pakets,
  3. ersetzt alte Dateipfade in allen .py-Dateien ("knowledge_base.json" -> "daten/wissensbasen/..."),
  4. fügt in Skripte und Apps zwei Zeilen ein, die lernassistent/pfadsetup.py laden
     (Importpfade + Arbeitsverzeichnis = Projektordner), damit alle Imports unverändert bleiben,
  5. ergänzt .gitignore, 6. prüft alle .py-Dateien auf Syntaxfehler,
  7. schreibt ein Rückgängig-Protokoll (ordne_projekt_protokoll.json).

Start (im Projektordner):
  python /tmp/v7/ordne_projekt.py              Probelauf: zeigt nur, was passieren würde
  python /tmp/v7/ordne_projekt.py --ausfuehren
  python /tmp/v7/ordne_projekt.py --rueckgaengig   (verschiebt zurück; Textänderungen: git checkout)
Vorher committen: git add -A && git commit -m "vor Umstrukturierung"
"""
import ast
import json
import shutil
import subprocess
import sys
from pathlib import Path

PAKET = Path(__file__).resolve().parent / "neu"
WURZEL = Path.cwd()
PROTOKOLL = WURZEL / "ordne_projekt_protokoll.json"

VERSCHIEBEN = {
    # Bibliothek
    "rag_pipeline.py": "lernassistent/rag_pipeline.py",
    "wissensgraph.py": "lernassistent/wissensgraph.py",
    "reranker.py": "lernassistent/reranker.py",
    "ideen_feedback.py": "lernassistent/ideen_feedback.py",
    # Wissensbasis
    "wissenbasis.py": "skripte/wissensbasis/baue_wissensbasis.py",
    "baue_wissensbasis.py": "skripte/wissensbasis/baue_wissensbasis.py",
    "baue_zweite_wissensbasis.py": "skripte/wissensbasis/baue_zweite_wissensbasis.py",
    "ordne_chunks_zu.py": "skripte/wissensbasis/ordne_chunks_zu.py",
    # Evaluation
    "fuehre_testfragen_aus.py": "skripte/evaluation/fuehre_testfragen_aus.py",
    "ragas_auswertung.py": "skripte/evaluation/ragas_auswertung.py",
    "stufen_check.py": "skripte/evaluation/stufen_check.py",
    "vergleiche_versionen.py": "skripte/evaluation/vergleiche_versionen.py",
    "vergleiche_laeufe.py": "skripte/evaluation/vergleiche_laeufe.py",
    "archiviere_version.py": "skripte/evaluation/archiviere_version.py",
    "verweigerung_neu_klassifizieren.py": "skripte/evaluation/verweigerung_neu_klassifizieren.py",
    "retrieval_vergleich.py": "skripte/evaluation/retrieval_vergleich.py",
    "teste_ideen_feedback.py": "skripte/evaluation/teste_ideen_feedback.py",
    "exportiere_stichprobe.py": "skripte/evaluation/exportiere_stichprobe.py",
    # Diagnose
    "frage_testen.py": "skripte/diagnose/frage_testen.py",
    "graph_erklaeren.py": "skripte/diagnose/graph_erklaeren.py",
    "retrieval_erklaeren.py": "skripte/diagnose/retrieval_erklaeren.py",
    # Läufe
    "lauf_V6.sh": "alt/lauf_V6.sh",
    # Daten
    "knowledge_base.json": "daten/wissensbasen/knowledge_base_boege.json",
    "knowledge_base_fischer.json": "daten/wissensbasen/knowledge_base_fischer.json",
    "knowledge_base_mit_platzhaltern.json": "alt/knowledge_base_mit_platzhaltern.json",
    "testfragen_v1.csv": "daten/testfragen/testfragen_v1.csv",
    "testfragen_fischer_v1.csv": "daten/testfragen/testfragen_fischer_v1.csv",
    "testideen_v1.csv": "daten/testfragen/testideen_v1.csv",
    "stichprobe_testfragen.json": "daten/testfragen/stichprobe_testfragen.json",
    "quellmaterial": "daten/quellen/boege",
    "quellmaterial_fischer": "daten/quellen/fischer",
    # Doku und Altes
    "PROZESSABLAUF.md": "doku/PROZESSABLAUF.md",
    "gitignore": "alt/gitignore_ohne_punkt",
}
# Konsolenausgaben und Pakete nach Muster
MUSTER = {"*.txt": "protokolle", "*.tar.gz": "alt"}
NICHT_ANFASSEN = {"requirements.txt"}

PFAD_ERSETZUNGEN = {
    "knowledge_base.json": "daten/wissensbasen/knowledge_base_boege.json",
    "testfragen_v1.csv": "daten/testfragen/testfragen_v1.csv",
    "testfragen_fischer_v1.csv": "daten/testfragen/testfragen_fischer_v1.csv",
    "testideen_v1.csv": "daten/testfragen/testideen_v1.csv",
    "stichprobe_testfragen.json": "daten/testfragen/stichprobe_testfragen.json",
    "quellmaterial": "daten/quellen/boege",
}

GITIGNORE_ZEILEN = [
    "# --- ab Umstrukturierung V7 ---",
    "daten/quellen/", "daten/wissensbasen/", "daten/extraktion/", "protokolle/", "alt/", "cache/",
    "__pycache__/", "evaluationsdaten/interaktionen*.csv", "evaluationsdaten/fragebogen.csv",
    "evaluationsdaten/ideen_feedback.csv", "evaluationsdaten/**/ragas_context_relevance_details.csv",
    "evaluationsdaten/hinweis_details_*.csv", "evaluationsdaten/*erklaerung_*.html",
    "evaluationsdaten/graph_*.html", "ordne_projekt_protokoll.json",
    "knowledge_base*.json", "*erklaerung_*.html", "*.bundle",
    "daten/testfragen/*fischer*",  # enthält Ankerzitate aus dem Fischer-Buch
]

KOPF = ('import sys as _sys, pathlib as _pl  # Projektpfade (lernassistent/pfadsetup.py)\n'
        '_sys.path.insert(0, str(next(p for p in _pl.Path(__file__).resolve().parents if (p / "lernassistent").is_dir()) / "lernassistent")); import pfadsetup  # noqa: E402,F401\n')


def von_git_verfolgt(pfad):
    r = subprocess.run(["git", "ls-files", "--error-unmatch", str(pfad)], cwd=WURZEL, capture_output=True)
    return r.returncode == 0


def plane():
    schritte = []
    for alt, neu in VERSCHIEBEN.items():
        if (WURZEL / alt).exists() and not (WURZEL / neu).exists():
            schritte.append((alt, neu))
    for muster, ordner in MUSTER.items():
        for p in sorted(WURZEL.glob(muster)):
            if p.name not in NICHT_ANFASSEN and p.is_file():
                schritte.append((p.name, f"{ordner}/{p.name}"))
    return schritte


def kopf_einfuegen(datei):
    text = datei.read_text(encoding="utf-8")
    if "import pfadsetup" in text:
        return False
    try:
        baum = ast.parse(text)
        zeile = 0
        if baum.body and isinstance(baum.body[0], ast.Expr) and isinstance(getattr(baum.body[0], "value", None), ast.Constant) \
                and isinstance(baum.body[0].value.value, str):
            zeile = baum.body[0].end_lineno
    except SyntaxError:
        zeile = 0
    zeilen = text.splitlines(keepends=True)
    if zeile == 0 and zeilen and zeilen[0].startswith("#!"):
        zeile = 1
    zeilen.insert(zeile, KOPF)
    datei.write_text("".join(zeilen), encoding="utf-8")
    return True


def pfade_ersetzen(datei):
    text = datei.read_text(encoding="utf-8")
    neu = text
    for alt, ziel in PFAD_ERSETZUNGEN.items():
        for q in ('"', "'"):
            neu = neu.replace(f"{q}{alt}{q}", f"{q}{ziel}{q}")
    if neu != text:
        datei.write_text(neu, encoding="utf-8")
        return True
    return False


def python_dateien():
    return [p for p in WURZEL.rglob("*.py") if ".venv" not in p.parts and "alt" not in p.parts
            and "__pycache__" not in p.parts and p.name != "ordne_projekt.py"]


def ausfuehren(nur_zeigen):
    schritte = plane()
    print(f"Projektordner: {WURZEL}\n1. Verschieben ({len(schritte)}):")
    for alt, neu in schritte:
        print(f"   {alt:45s} -> {neu}")
    neue = sorted(p.relative_to(PAKET) for p in PAKET.rglob("*") if p.is_file())
    print(f"2. Aus dem Paket kopieren ({len(neue)}):")
    for p in neue:
        print(f"   {p}{'  (ersetzt vorhandene Datei)' if (WURZEL / p).exists() else ''}")
    unbekannt = [p.name for p in WURZEL.glob("*.py") if p.name not in VERSCHIEBEN and p.name not in ("app.py", "admin_app.py")]
    if unbekannt:
        print(f"   Hinweis: unbekannte .py-Dateien bleiben im Hauptordner: {unbekannt}")
    if nur_zeigen:
        print("\nProbelauf – nichts geändert. Ausführen mit --ausfuehren")
        return

    protokoll = {"verschoben": []}
    for alt, neu in schritte:
        ziel = WURZEL / neu
        ziel.parent.mkdir(parents=True, exist_ok=True)
        if von_git_verfolgt(alt):
            subprocess.run(["git", "mv", alt, neu], cwd=WURZEL, check=True)
        else:
            shutil.move(str(WURZEL / alt), str(ziel))
        protokoll["verschoben"].append([alt, neu])
    for p in neue:
        ziel = WURZEL / p
        ziel.parent.mkdir(parents=True, exist_ok=True)
        shutil.copy2(PAKET / p, ziel)
    for ordner in ("daten/quellen/boege", "daten/quellen/fischer", "daten/extraktion", "daten/wissensbasen",
                   "protokolle", "doku", "alt"):
        (WURZEL / ordner).mkdir(parents=True, exist_ok=True)
    pc = WURZEL / "__pycache__"
    if pc.exists():
        shutil.rmtree(pc)

    print("3. Pfade ersetzt in:", [str(p.relative_to(WURZEL)) for p in python_dateien() if pfade_ersetzen(p)])
    kopf = [p for p in python_dateien() if ("skripte" in p.parts or p.parent == WURZEL) and kopf_einfuegen(p)]
    print("4. pfadsetup-Kopf eingefügt in:", [str(p.relative_to(WURZEL)) for p in kopf])

    gi = WURZEL / ".gitignore"
    vorhanden = gi.read_text(encoding="utf-8").splitlines() if gi.exists() else []
    fehlend = [z for z in GITIGNORE_ZEILEN if z not in vorhanden]
    with open(gi, "a", encoding="utf-8") as f:
        f.write("\n" + "\n".join(fehlend) + "\n")
    print(f"5. .gitignore um {len(fehlend)} Zeilen ergänzt")

    fehler = []
    for p in python_dateien():
        try:
            ast.parse(p.read_text(encoding="utf-8"))
        except SyntaxError as ex:
            fehler.append(f"{p.relative_to(WURZEL)}: {ex}")
    print("6. Syntaxprüfung:", "alles in Ordnung" if not fehler else "\n   " + "\n   ".join(fehler))
    PROTOKOLL.write_text(json.dumps(protokoll, ensure_ascii=False, indent=1), encoding="utf-8")
    print(f"7. Protokoll: {PROTOKOLL.name}\nFertig. Weiter mit: python skripte/setup/pruefe_umgebung.py")


def rueckgaengig():
    protokoll = json.loads(PROTOKOLL.read_text(encoding="utf-8"))
    for alt, neu in reversed(protokoll["verschoben"]):
        if (WURZEL / neu).exists():
            if von_git_verfolgt(neu):
                subprocess.run(["git", "mv", neu, alt], cwd=WURZEL)
            else:
                shutil.move(str(WURZEL / neu), str(WURZEL / alt))
            print(f"zurück: {neu} -> {alt}")
    print("Dateien zurückverschoben. Textänderungen in verfolgten Dateien: git checkout -- .")


if __name__ == "__main__":
    if "--rueckgaengig" in sys.argv:
        rueckgaengig()
    else:
        ausfuehren(nur_zeigen="--ausfuehren" not in sys.argv)
