# Scaffolding Specification — Lernassistent (Hinweis → Erklärung → Lösung)

**Version:** S-v2 (12 Oct 2026) · **Status:** **two stages since V4** (decided by Vel on 12 Oct; §2.1): Hinweis → [Deine Idee? + feedback] → Lösung with explanation. Implemented: prompt **S2-v1** in `rag_pipeline.py` (two stages + Hinweis rules H1–H3), "Deine Idee?" (§5.1, prompt IF-v1). The three-stage prompt of V0–V3 remains selectable as **S3-v0**. Evaluation of V4 still open.
**Purpose:** a concrete, citable definition of the scaffolding in the Lernassistent: what each stage must and must not do, where each rule comes from, and how each rule is checked. This replaces the informal stage descriptions in `baue_scaffolding_prompt()` and §3 of `claude/Prompt_Principle_Mapping.md` (Sept 2026) as the reference for the dissertation's design chapter.
**Sources:** Vel's Notion "Paper Reading list" (division 7 *Scaffolding & Tutor Design*, plus 6 and 8). Each claim carries its source. Markers: **(N)** = from Vel's Notion reading notes · **(N, to read)** = in Notion but not yet read by Vel; verify before citing · **(via X)** = primary source cited through paper X, not read directly · **[Own data]** = measured on our system.

---

## 1. Working definition

**Scaffolding** is temporary, graduated support that lets a learner solve a task they could not yet solve alone. It is withdrawn as competence grows, so that responsibility passes to the learner. **(Wood, Bruner & Ross, 1976; Reiser, 2004 — via Neagu et al., 2026)**

Two elements make the definition operational:

1. **Balancing act.** Withholding help can turn an impasse into productive struggle, but risks frustration and bypassing. Giving direct help supplies information, but invites shallow learning. Good scaffolding gives **minimal or graduated help** and **withholds the direct answer**, so the learner stays in control. **(Neagu et al., 2026 (N); assistance dilemma: Koedinger & Aleven, 2007, via Neagu)**
2. **Three characteristics: contingency** (support adapted to the learner's current state), **fading** (support decreases over time) and **transfer of responsibility** (the learner takes over). **(van de Pol, Volman & Beishuizen, 2010 (N, to read))**

**Theoretical base:** Zone of Proximal Development (Vygotsky, 1978): the gap between what a learner can do alone and with guidance. Hints structured "in a scaffolded manner, with incremental steps leading to the solution" **(Jangra et al., 2025, §2.1 (N))**. Scaffolding is "equal parts motivational and cognitive support" **(Klein et al., 2026 (N), citing Wood; check their reference [95])**.

---

## 2. What our design is — and what it is not

**Design type:** fixed, **learner-controlled graduated support** with three stages, generated in **one** LLM call from the retrieved context and unlocked one after another in the app. This is principle **P2b "productive friction with graduated support"** **(Klein et al., 2026 (N))**: not too easy, but the learner is not left stuck; help comes step by step, only as much as requested.

**The three stages are three of the six scaffolding means** of van de Pol et al. (2010): **Hinweis = hinting, Erklärung = explaining, Lösung = modeling** (worked example). This follows Chen, Li et al. (2026, CHI EA) **(N)**, who mapped these means onto LLM tutor interaction designs. *Sentence for the dissertation (Vel's note):* "The three stages operationalize three of the six scaffolding means of van de Pol et al. (2010), hinting, explaining and modeling, similar to Chen et al. (2026)."

**Honest limitations, to be stated in the dissertation:**

| Characteristic (van de Pol) | Realized in the Lernassistent? |
|---|---|
| Contingency | **Only through learner self-selection.** The learner decides how deep to go (stage 1, 2 or 3). The system has no learner model and does not diagnose the learner's state. Contrast: Copa chooses a dialogue policy per learner from a learner model **(Cohn et al., 2026 (N))**. |
| Fading | **Not implemented by the system.** It can only be *measured*: does the share of Lösung requests fall over sessions? (Klein indicator 5) |
| Transfer of responsibility | **Partly.** The learner must actively ask for more help, but there is no step where the learner produces something (no own attempt; cf. §5, decision D2). |

Copa, Klein et al. and Cohn et al. (AAAI 2026) argue for **adaptive** rather than fixed-stage scaffolding **(N)**. Defensible framing: *three fixed stages are a deliberate simplification of a continuous construct, chosen for a local, non-agentic pipeline, transparent logging and a controlled study; adaptivity is future work.* The simplification also has an ethical argument: the learner-chosen Lösung stage acts as the **learner override** that Klein et al. recommend against paternalistic "obligatory" friction **(N)**.

### 2.1 Decision 12 Oct 2026: two stages instead of three (V4)

**Vel's decision:** the Erklärung and the Lösung are not both needed now that there is stepwise help. The separate Erklärung is dropped; the **Lösung includes a short explanation** (answer first, then why; worked steps for calculations).

**Reasons:**
- **[Own data, V3]:** the Erklärung and Lösung were largely redundant. Median length was 48 vs. 42 words, and the Erklärung often already stated the result (e.g. Q1: the whole method; manual test Q3: FeS and MnS).
- **The middle step is now contingent:** feedback on the learner's own idea replaces the generic Erklärung. This is ladder level 2, *targeted feedback* **(Zourlidou et al., 2026 (N))**, and the scaffolding means *feedback* **(van de Pol et al., 2010 (N, to read))**.

**New mapping:**

| Stage | Scaffolding means (van de Pol) | Hint-ladder level (Zourlidou) |
|---|---|---|
| Hinweis | hinting | 1 |
| Deine Idee + feedback (optional, max. 3) | feedback | 2 |
| Lösung with explanation | explaining + modeling | 4 |

The old Erklärung rules E1–E4 now apply to the explanation part of the Lösung. E2 ("no result") is dropped, because the Lösung gives the result. Rule X1 (progression) applies between Hinweis → feedback → Lösung.

**Effects:**
- `scaffolding_stufe_erreicht` is now 1 = Hinweis, 2 = Lösung (V0–V3: 1–3)
- the `erklaerung` column in `interaktionen.csv` stays, but is empty, so the log format is unchanged
- TAM item SCAFF1 has new wording (Hinweis → eigene Idee mit Rückmeldung → Lösung)
- the parse check in `ragas_auswertung.py` now only requires the Hinweis

---

## 3. Stage specifications

Each stage is also mapped onto the 5-level **hint ladder** of Zourlidou et al. (2026, AIED) **(N)**: 0 orientation → 1 hint → 2 targeted feedback → 3 partial worked step → 4 full solution.

### 3.1 Stufe 1 — Hinweis (hinting; ladder levels 0–1) — *revised 13 Oct 2026 (H-v2)*

**Function:** point the learner to the **concept, quantity or next thinking step** before any attempt, without giving the answer.

**What kind of hint this is.** Jangra et al. (2025, TACL 13) survey two strands of hint research:
- **QA hints**: a hint for a question, *before* any attempt (Jatowt et al., 2023; Mozafari et al., 2024b, TriviaHG). **This is our Hinweis.**
- **Error-based hints**: a hint *after* a wrong attempt, built from error type and strategy (maths/programming; Wang et al., 2023). This corresponds to our **idea feedback** (§5.1), not to the Hinweis.

**Formal definition** (Jangra et al., 2025, §4.1, pp. 511–512; Eq. 1–3 on p. 512, building on Jatowt et al., 2023, p. 511). A hint h for question q, answer a and learner context D is good if:
1. P(a | q, h, D) < 1 → it **does not give away the answer**
2. P(a | q, h, D) − P(a | q, D) > ε → it **makes finding the answer more likely**
3. learning gain with h − without h > ε → it **serves learning**, not just this task

**Rules** (page numbers refer to Jangra et al., 2025; *classic* = older primary literature behind the idea; ⚠ = from my knowledge, not in Vel's Notion list, verify before citing):

| Rule | Content | Source in Jangra et al. (2025) | Classic / primary literature |
|---|---|---|---|
| **H1 — Do not reveal** | No result, value, formula or core statement (nothing that *is* the answer) | §4.1, Eq. 1, p. 512; *telling rate* (Pal Chowdhury et al., 2024), §3.2, p. 510 | Hume, Michael, Rovick & Evens (1996), *Hinting as a tactic in one-on-one tutoring*, J. Learning Sciences 5(1), 23–47 ⚠ (hints prompt the learner to retrieve/infer instead of telling); VanLehn (2006), *The behavior of tutoring systems*, IJAIED 16(3), 227–265 ⚠ (hint sequences; only the last, "bottom-out" hint gives the answer) |
| **H2 — Point the direction (convergence)** | Name the concept, quantity or next step so that wrong directions are ruled out; not a restatement of the question | §4.1, Eq. 2, p. 512; *convergence* (Mozafari et al., 2024b), §3.2, p. 510 | Reiser (2004): *structuring* (directing attention, reducing complexity) ⚠ content from my knowledge; Wood et al. (1976): *reduction in degrees of freedom*, "simplifying the task by reducing the number of constituent acts required to reach solution" (p. 98, checked); Hume et al. (1996) ⚠; Zourlidou et al. (2026), ladder level 1 (N) |
| **H3 — Only what the learner can see or knows (familiarity)** | Refer only to the question and general trainee knowledge; no „Kontext / Tabelle / Abschnitt / Liste"; no new technical terms from the Lösung | *familiarity* (Mozafari et al., 2024b), §3.2, p. 510, which they measure via Wikipedia page views (not transferable, so our operationalisation is the word check in `stufen_check.py` + human rating); *Link to Prior Knowledge*, §2.2, p. 506 (Hailikari et al., 2007, 2008; Dong et al., 2020) | Ausubel (1968), *Educational Psychology: A Cognitive View* ⚠ (“the most important single factor influencing learning is what the learner already knows”); Jangra cite Ausubel (1962, 1963, 2012) in §4.1 |
| **H4 — Conceptual depth (balance)** | Demanding enough to make the learner think, not so easy that the answer is given away, not so vague that it helps nothing (Q21 vs. Q10) | *Conceptual Depth*, §2.2, p. 506–507 (Rillero, 2016) | Reiser (2004), *structuring* vs. *problematizing* and the tension between them, J. Learning Sciences 13(3), 273–304 (via Neagu et al., 2026, p. 3); Koedinger & Aleven (2007), *assistance dilemma*, Educ. Psych. Review 19(3), 239–264 (via Neagu et al., p. 3); Wood, Bruner & Ross (1976) |
| **H5 — Clear and simple** | 1–2 short sentences, simple language, technical terms only if they appear in the question; may end with one guiding question | *Clarity and Simplicity*, §2.3, p. 507 (Kozloff et al., 1999; Kim & Axelrod, 2005; Rosenshine, 2008) | Rosenshine (2012), *Principles of Instruction*, American Educator 36(1), 12–19 ⚠; Sweller (1988), Cognitive Science 12(2), 257–285 ⚠ (cognitive load); guiding question: Neagu et al. (2026) (N), Klein et al. (2026) P3 (N) |

**Applies to the whole sequence, not to a single Hinweis:**
- *Scaffolding Support* (§2.1, p. 506: Wood et al., 1976; Zurek et al., 2014; Lin et al., 2012; Hammond, 2001) justifies Hinweis → feedback → Lösung as incremental steps ("just-in-time interventions"). It is not a rule for one Hinweis. Primary theory: Wood, Bruner & Ross (1976); Vygotsky (1978) (ZPD, cited in Jangra's introduction, p. 505); van de Pol et al. (2010) (N, to read).

**Deliberately not adopted, or only in a limited way** (state as limitations):

| Property in Jangra et al. (2025) | Decision | Reason |
|---|---|---|
| *Relevance to the Learning Objective* (§2.2, p. 506; Hoque, 2016; Sönmez, 2017) | Limited: only as "points to the concept the question asks about" (part of H2) | No learning objective per question: learners ask freely, and there is no mapping to Lernfelder or a curriculum. Classic: Anderson & Krathwohl (2001), revised Bloom taxonomy ⚠ |
| *Link to Prior Knowledge* (§2.2) | Limited: only as "use terms the learner knows" (H3) | No learner model, and linking to knowledge outside the context conflicts with the grounding pillar |
| *Encouragement and Positive Tone* (§2.3, p. 507; Ducca, 2014; Yuan et al., 2019; Li, 2021; Lalić, 2005) | Moved to the **feedback** (F3), not the Hinweis | The Hinweis comes before any attempt, so there is little to encourage. Classic for feedback: Hattie & Timperley (2007), *The power of feedback*, RER 77(1), 81–112 ⚠ |
| *Personalization and Learner Feedback* (§2.1) | Not adopted | No learner model (fixed stages, §2) |
| *Creative and Multi-modal Elements* (§2.3) | Not adopted | Text only; figures belong to the later VLM step |

**Quotes and lineage** (verbatim passages, Wood/Reiser lineage, which paper cites whom): see `claude/Zitate_Hinweis_Scaffolding.md`.

**Note on source quality:** several sources Jangra et al. cite in §2 are low-tier (e.g. Hoque, 2016, *J. EFL Education and Research*; Kozloff et al., 1999, no volume or pages). For the dissertation, cite Jangra et al. (2025) for the synthesis and the classic sources (Wood et al., 1976; Hume et al., 1996; VanLehn, 2006; Koedinger & Aleven, 2007; Ausubel, 1968; Rosenshine, 2012) for the underlying ideas, after checking them.

**V5 (S2-v2, 13 Oct 2026): Hinweis in a separate, answer-aware call (prompt H-v3).** V4 showed that rules in the joint prompt barely reduced leakage (preliminary manual rating, 22 questions: V3 good 6 / partial 5 / full 5 → V4 good 7 / partial 6 / full 4). Change:
- Call 1 is the unchanged S2-v1 prompt (byte-identical), so at T=0/seed 42 the Lösung equals V4's. Only its Lösung is used.
- Call 2 (`baue_hinweis_prompt`) sees question, context **and the Lösung**, gets rules H1–H5 explicitly, and must first write a hidden `UEBERLEGUNG` field: (a) which words and numbers of the Lösung must not appear, (b) which thinking step leads there. Then `HINWEIS:`. Same pattern as the idea feedback IF-v1 (§5.1).
- No call 2 if call 1 was not parsed or the Lösung is a refusal (`hinweis_quelle` = `aufruf1` / `aufruf1_verweigerung`); format error in call 2 → keep the call-1 Hinweis (`aufruf1_formatfehler`).
- Diagnostics (old vs. new Hinweis, UEBERLEGUNG) go to `evaluationsdaten/hinweis_details_<ID>.csv` (gitignored), not to `interaktionen.csv` (format unchanged).
- New automatic H1 check in `stufen_check.py`: numbers in the Hinweis that are in the Lösung but not in the question.
- Cost: one extra generation call per question (expected +3–6 s, to be measured).
- Rationale: answer-aware hint generation is the setup assumed by the formal definition (h is generated for q **and a**; Jangra et al., 2025, §4.1, p. 512). That a separate call reduces leakage is a **hypothesis**, tested by V4 vs. V5 on the same 30 questions.

**Mapping to the old rule names** (H-v1, used in §6–8 and in the S2-v1 prompt): H1 = H1; H2 = H2 + convergence; H3 = H3 + familiarity; H4 (form) is now H5; H4 (conceptual depth) is new.

### 3.2 Stufe 2 — Erklärung (explaining; ladder levels 2–3) — *dropped as a separate stage in V4 (§2.1); E1, E3 and E4 now apply to the explanation in the Lösung*

**Function:** explain the **concept or method** from the context that is needed to answer, so the learner can complete the last step alone.

| | Rule | Source |
|---|---|---|
| **E1 — must** | Add information beyond the Hinweis (concept, relationship, procedure) | Progression requirement (§4, X1) |
| **E2 — must not** | State the final result. For calculations: give the formula and the procedure, **not** the number | Zourlidou recommendation 4, "separate explanation from computation"; level 3 = exactly **one** worked sub-step (N) |
| **E3 — must** | Explain only relationships that are in the context (grounding applies to every stage; faithfulness is judged on all three) | RAGAS setup §7.4 of `Entwicklung_und_Evaluation.md`; Es et al. (2024) |
| **E4 — form** | Technical terms explained in plain words at trainee level; length as needed (no fixed sentence count) | Sweller (cognitive load), via Prompt_Principle_Mapping; COGENT: without a target level, LLM texts are 2–3 grades too hard (N) |

### 3.3 Stufe 3 — Lösung (modeling / worked solution; ladder level 4)

**Function:** the complete, correct answer as a **worked model** that the learner can check their own thinking against.

| | Rule | Source |
|---|---|---|
| **L1 — must** | State the complete answer to the question | — |
| **L2 — must** | For calculations and procedures: show the steps, with numbers (modeling = worked example) | van de Pol *modeling* (N, to read); Chen et al. "step-by-step reveal" (N) |
| **L3 — must** | Be consistent with Hinweis and Erklärung (no contradiction) | Copa: measured grounding / alignment / faithfulness along the evidence → decision → feedback chain (Cohn et al., 2026, RQ5 (N)) |
| **L4 — must** | Show the source (chapter/page) together with the Lösung, so the learner can check it against the handbook | Vendrell & Johnston P3 "evaluation as standard practice" (N); Klein *Expertise Paradox*: novices accept fluent output too quickly (N) |

---

## 4. Cross-stage rules

| | Rule | Source / reason |
|---|---|---|
| **X1 — progression** | Information increases strictly: Hinweis ⊂ Erklärung ⊂ Lösung. No stage repeats the previous one without adding something | Jangra: incremental steps (N); documented live-test failure "stage redundancy" (Prompt_Principle_Mapping §3) |
| **X2 — consistency** | The three stages do not contradict each other | Live-test failure "internal inconsistency" (Scaffolding_Reading_List); Copa chain checks (Cohn et al., 2026 (N)) |
| **X3 — register** | One consistent form of address: **„du"** (trainees). ⚠ decision for Vel: „du" vs. „Sie" | Own finding: V3 mixes both (§6) |
| **X4 — grounding** | All three stages use only the context | Pillar *Grounding*; faithfulness is computed over all three stages |
| **X5 — format** | Exactly three markers, so `parse_scaffolding_antwort()` can split them. *A technical rule, not a didactic principle* | Prompt_Principle_Mapping §3 |

---

## 5. Interaction design (app) — open decisions for Vel

Current behaviour (`app.py`): the Hinweis is shown first. Buttons unlock the Erklärung and then the Lösung; each step is logged (`scaffolding_stufe_erreicht`). **Sources are shown only at stage 3** (or for unparsed and gate cases).

| # | Decision | Options | Literature |
|---|---|---|---|
| **D1** | Free unlocking or a gate before the Lösung? | (a) keep free unlocking (current; learner override) · (b) Zourlidou gate: Lösung only after an own attempt + ≥ 1 scaffold step | Zourlidou: union of gates would have delayed or reframed 64.3 % of full-solution turns (N); Happe et al.: learners found hint-first scaffolding "overly cautious" (N); Copa: withholding answers → usefulness 2.77/5 (N) |
| **D2** ✅ **decided 12 Oct: (b), interactive** — see §5.1 | Own attempt before help? | (a) no · **(b) optional free-text field "Deine Idee?" with feedback, logged** | Vendrell & Johnston P1 + P8 (own attempt first) (N); Kosmyna et al. (2025), via Vendrell & Johnston: better results when students worked alone first |
| **D3** | What happens when the context does not answer the question? | (a) current: model says so "in all three stages" · (b) no stages; one abstention message | Own finding: three stages of refusal text are empty scaffolding (§6, Q23–Q30) |
| **D4** | When are sources shown? | (a) stage 3 only (current) · (b) with the Lösung *and* named in the Hinweis as chapter only | Rule H3 / L4 |

**Recommendation for the pilot study:** keep D1 (a) and add D2 (b) as optional and logged. This keeps the study design simple, gives a measure of transfer of responsibility, and avoids the helpfulness paradox. D1 (b) changes the treatment and should be a separate DBR cycle. *D2 was decided by Vel on 12 Oct 2026; D1, D3 and D4 are still open.*

### 5.1 "Deine Idee?" — interactive feedback on the learner's own attempt (D2, implemented 12 Oct 2026)

**Flow:** Hinweis → optional free-text idea → short feedback that does not reveal the answer → (more ideas possible) → Erklärung → (more ideas possible) → Lösung.

**Placement in the theory:**
- **Feedback** is a fourth scaffolding means of van de Pol et al. (2010) **(N, to read; mapping via Chen et al., 2026 (N))**. It corresponds to ladder level 2, *targeted feedback*: check one learner step and point to one local mistake **(Zourlidou et al., 2026 (N))**.
- **Transfer of responsibility:** the learner produces something before receiving more help **(Vendrell & Johnston, 2026, P1/P8 (N))**.
- **Evidence from real students:** responses to the learner's own attempt ("verification feedback") were the most productive response type (82.4 %); direct answers were the least productive (62.7 %) **(Abrar, Sharmin & Barmaki, 2027 (N))**.

**Feedback rules:**

| | Rule | Source |
|---|---|---|
| **F1** | Judge the idea only against the context and the reference Lösung (*answer-aware*: the model sees the hidden Lösung) | Bhaskar & Hamouda (2025) (N); Petukhova, Nguyen & Kochmar (2026): Qwen3-8B tutors work best with a gold solution (N) |
| **F2** | Never reveal the result, value, formula or core statement unless it is already in the idea (= H1 for feedback) | MRBench *Revealing Answer* (N); Jangra criterion 1 (N) |
| **F3** | Start with what is right, then name **exactly one** wrong or missing point without correcting it, then a guiding question or next step | Klein P4 *competence-supportive feedback* (N); Zourlidou level 2 (N); MRBench *Mistake Identification / Location*, *Actionability* (N) |
| **F4** | Verdict in one of four classes: richtig / teilweise / falsch / keine_idee. Logged, shown to the learner as an icon only | Basis for analysis (how good were the ideas, per stage) |
| **F5** | Short private reasoning **before** the feedback; never shown. The raw output is never shown either: if the format fails, a neutral fallback text appears | Zhao, Knežević & Käser (2026): reasoning-first cut leakage 46 % → 2 % for Qwen-32B (N) |
| **F6** | „du", at most 3 sentences, no reference to "the context" (= H3) | X3, H3 |

**Implementation** (`ideen_feedback.py`, prompt version **IF-v1**; `app.py`):
- one extra qwen call per idea (T = 0, seed 42), reusing the retrieved chunks (no new retrieval)
- at most **3 ideas per question**, only for the newest question and only until the Lösung is opened
- no idea field after a gate refusal, an unparsed answer, or a model refusal (refusal detector v2)
- **separate log** `evaluationsdaten/ideen_feedback.csv`, because the format of `interaktionen.csv` is used by RAGAS and all evaluation scripts. Columns: session, question no., attempt no., stage at the attempt, idea, verdict, feedback, hidden reasoning, parse status, number-leak flag, seconds, prompt version. ⚠ This is learner data: add it to `.gitignore`.
- **number-leak flag:** numbers in the feedback that appear in the Lösung but not in anything the learner has seen. This is logged only and does not intervene. It cannot detect leaked *words*, so human rating is still needed.
- the consent text on the start page now mentions that ideas are stored

**Test** (`teste_ideen_feedback.py`, `testideen_v1.csv`):
- 8 questions (Q1, 3, 8, 10, 14, 17, 20, 21) × 4 idea types (richtig, teilweise, falsch, keine Ahnung) = 32 cases
- ⚠ ideas and expected verdicts were drafted by Claude; Vel should check them
- **automatic:** verdict accuracy, format rate, number-leak flags, time
- **by hand** (§7 scale): S1 reveals the answer · S2 helpful · mistake identified
- Q20's wrong idea is V2's sequential hallucination ("erst den einen, dann den anderen Taster"), and Q21's wrong idea is the I-term misconception

**Offline checks done (no LLM):**
- 15 unit tests: parser incl. umlaut markers and broken output, leak check, prompt contents, log format, idea-field conditions
- 13 headless app tests with Streamlit AppTest: stage order, empty input, three-attempt limit, field only for the newest question, no field after a refusal
- the real model behaviour is **not tested yet**; that needs a run on Ollama

**First model test, IF-v1 (12 Oct 2026)** [Own data: `test_ideen_feedback_IF-v1.csv`, `ideen_test_IF-v1.txt`; generator qwen3.5:9b, retrieval hybrid_kg_rr, k = 5]

*Automatic measures:*

| Measure | Result |
|---|---|
| Format parsed | 32/32 |
| Verdict as expected | 28/32 — partly right 8/8, wrong 8/8, no idea 8/8, **right 4/8** |
| Number-leak flag | 0/32 |
| Median time per feedback | 3.5 s (max 9.0 s) |

*Rating* — ⚠ **one rater (Claude), preliminary.* "Reveals" means beyond what the learner had already seen (question, Hinweis, own idea):

| Finding | n | Cases |
|---|---|---|
| Reveals nothing new (S1 = nein) | 26/32 | — |
| Reveals part of the answer (S1 = teilweise) | 4 | Q1 partly right (conversion to ω), Q10 wrong (count "underestimated"), Q14 partly right ("Kühlung verringert die Arbeit"), Q20 no idea (time window) |
| **Corrects instead of pointing (S1 = ja, breaks F2/F3)** | 2 | Q17 partly right (gives the full reason), Q20 wrong ("innerhalb eines sehr kurzen Zeitfensters") |
| Mistake identified in wrong ideas | 8/8 | e.g. Q21: names the I-term misconception |
| **Too strict: correct idea judged "teilweise"** | 4/8 | Q8, Q14 (the Lösung has extra aspects), Q20 (wants "Schließertaster"), Q21 (wants the word "Vorteil") |
| Refers to text the learner cannot see (breaks F6/H3) | 3 | Q10 partly right, Q17 partly right, Q17 wrong ("Lernmaterial", "Text") |
| Other | 4 | Q8 no idea: "?" read as a copied Hinweis; Q10 wrong: names two mistakes; Q1 and Q17 right: a new follow-up task after a correct answer |

*Observations:*
- **Several Hinweise in this run already give away part of the answer** (Q3, Q8, Q21). This hides feedback leakage and confirms the stage-1 problem from §6.
- ⚠ **Hinweise differ from the V3-RR batch run with the same configuration** (e.g. Q8, Q17, Q20), although T = 0 and seed 42. Determinism was verified only for V1 (T0a = T0b). Cause not checked; possible candidates are retrieval order with the reranker on CPU, or a different code state.

*Candidate changes for IF-v2:*
1. "richtig" = the core statement is correct; missing details or other wording are no reason for "teilweise"; no new task after a correct idea
2. "Do not say what would be correct instead", with a negative example
3. For "keine Ahnung": no new content, only a question back to the Hinweis
4. An automatic flag for "Lernmaterial / Kontext / Text / Musterlösung" in the feedback, like the number flag
5. No either-or questions whose options contain the answer. *Manual app test, Q3, idea „Mangan bindet den Schwefel zu Eisensulfid …":* the feedback asked *„Welches der beiden möglichen Sulfide (Eisen- oder Mangansulfid) …"*. With two options and one ruled out by the learner's own idea, this gives the answer away (S1 = teilweise; breaks F2, since „Mangansulfid" was not in the idea).
   *Same manual test, attempt 3, idea „manganese sulfide" (English):* understood, but judged 🟡 although the core compound is right. The feedback then gives away the rest of the answer (*„um das schädliche Eisensulfid zu vermeiden"*), so S1 = ja. After three attempts the learner never saw ✅ despite clear progress, which is the over-strictness problem from the test run, now as a learner experience. The three-attempt limit worked as designed.
   *Erklärung in the same answer* (stage text, not feedback): states FeS and MnS outright, so there is little left for the Lösung (E2/X1). It also contains *„Mangan wirkt hier als Desoxidationsmittel"*: ⚠ not checked whether this is in the context; possibly model knowledge.
   *False-premise test (app, dense retrieval), „Bei welcher Temperatur schmilzt der D-Anteil eines PID-Reglers?":* qwen invents no value, and all three stages refuse consistently; there was no idea field. **Grounding: correct** (Vel's assessment, agreed). The model does not explicitly reject the premise (*„keine Informationen zum Schmelzpunkt des D-Anteils"*). Doing so (*„der D-Anteil ist kein Bauteil"*) would be a pedagogical improvement, but it is an inference beyond the text, so it **conflicts with the grounding pillar**. Classified as an optional pedagogical point, not an error. One detail: the Erklärung's phrase *„Materialgrenzen von Reglerkomponenten wie dem D-Anteil"* treats the D-Anteil as a physical part, which is a minor wording problem. The Hinweis talks about „den Kontext" (H3). A **false-premise** question type is useful for the test set.
   *Manual app test with V4 (S2-v1, dense), Q10:*
   - **Hinweis:** no leak and no „Kontext", but weak (it restates the question; S2 = teilweise). It also says *„ganz oben in der Liste"*, a list the learner does not have.
   - **Feedback on two wrong ideas** („16 Grade, IT18 …", „IT18"): both judged 🟡 instead of falsch, so too lenient here; in the 32-case test, wrong ideas were 8/8 correct.
   - Both feedbacks say *„Schau dir die Liste an"* (F6/H3 in a new form: no "Kontext", but an instruction to look something up).
   - Feedback 2 corrects (*„dieser Grad ist am wenigsten genau"*), so S1 = teilweise.
   - **Lösung:** correct; answer first, then reason (L1/L2 ✓); sources fit (34.2 ISO-Passungen).
   - → IF-v2 / S2-v2 candidate 7: no instructions to look something up („Liste", „Tabelle", „Abschnitt"); the learner has only the question, the Hinweis and the feedback.
6. Grounding of the feedback itself: in the manual test, the first feedback said *„beim Schmieden oder Spanen"*, but the Lösung says only Schmieden; the error was already in qwen's hidden reasoning. RAGAS does not score feedback text, so this needs a check of its own (rating criterion or an extra faithfulness pass)

**New measures for the pilot (F3):**
- share of questions with at least one idea (*attempt rate*)
- verdict distribution per stage
- whether ideas get better between attempts
- these complement uptake (`scaffolding_stufe_erreicht`) and the shortcut-use rate

---

## 6. Baseline: V3-RR answers against this specification [Own data]

**Data:** 30 answers of the V3-RR batch run (`archiv/V3-RR/interaktionen.csv`, generator qwen3.5:9b, current prompt).

**Automatic measures:**
- **Format compliance (X5):** 29 of 30 parsed; Q25 fell back to a plain answer
- **Median length (words):** Hinweis 32 · Erklärung 48 · Lösung 42. The Lösung is often *not* longer than the Erklärung, which suggests a weak *modeling* stage (L2)
- **Register (X3)** (regex heuristic): „du" in 11 answers, „Sie" in 9, neither in 10, never both in one answer → inconsistent **across** answers

**Hint rating (H1–H3)** — ⚠ **preliminary: one rater (Claude), not validated.** Covers the 21 answered in-domain questions (Q1–Q22 without Q5, which was refused):

| Category | Questions | n |
|---|---|---|
| Good: points to concept or next step, no leak | Q1, Q6, Q12, Q14, Q17, Q18 | 6 |
| Partial leak: gives part of the answer | Q3, Q8, Q10, Q11, Q16 | 5 |
| **Full leak: the Hinweis already contains the answer (H1)** | **Q9, Q15, Q20, Q21, Q22** | **5** |
| **Points to the hidden context (H3)** | **Q2, Q4, Q7, Q13, Q19** | **5** |

Examples:
- **Q9 (full leak):** Hinweis *„Das vereinfachte Modell reicht dann aus, wenn die Bewegung des Pendels nur kleine Ausschläge vollführt …"* = the Lösung.
- **Q20 (full leak):** Hinweis already names *„gleichzeitig"* and *„200 ms"*.
- **Q4 (H3):** *„Suchen Sie im Kontext nach dem Abschnitt über Drehteile auf Automaten …"*. The learner has no context to search.
- **Q1 (good):** *„… überlegen, wie die elektrische Leistung des Motors mit seiner Drehzahl und dem Drehmoment zusammenhängt."*

**Refusals (D3):** for Q23–Q30, all three stages repeat that the context does not answer the question. Q27's Hinweis even talks about the prompt rules (*„… was gegen die Anweisung verstößt, nur den Kontext zu nutzen"*).

**Reading:** on this preliminary rating, only 6 of 21 hints meet H1–H3. Rule violations cluster in H1 (leakage: 10 partial or full) and H3 (5). This matches the documented live-test failure "hint leakage" and the literature (7–8B tutors leak in 40–75 % of adversarial dialogues — Zhao, Knežević & Käser, 2026 (N); GPT-4 reveals the answer ~47 % — Maurya et al., 2025 (N)). Note that our 10 of 21 come from **non-adversarial** single questions.

---

## 7. Evaluation instrument (operationalization)

One rating per answer and stage, **3-level scale Yes / To some extent / No** (as in MRBench, κ 0.71 — Maurya et al., 2025 (N)).

| Criterion | Stage | Question for the rater | Source |
|---|---|---|---|
| S1 Revealing answer | Hinweis, Erklärung | Does the stage reveal the final answer or result? | MRBench (N); Jangra crit. 1 (N) |
| S2 Providing guidance | Hinweis, Erklärung | Does it give correct, relevant guidance towards the answer? | MRBench (N); BEA 2025 (N) |
| S3 Actionability | Hinweis | Is it clear what the learner should think about or do next? | MRBench (N) |
| S4 Visible reference | Hinweis | Does it refer only to things the learner can see? | Rule H3 |
| S5 Progression | Erklärung, Lösung | Does the stage add information beyond the previous one? | X1 |
| S6 Consistency | all | Does any stage contradict another? | X2 |
| S7 Modeling | Lösung | For calculations/procedures: are the steps shown? | L2 |
| S8 Faithfulness | all, **per stage** | Existing RAGAS faithfulness, split by stage instead of pooled | Es et al. (2024) |
| S9 Format, register | all | Automatic: parsed? one consistent form of address? | X3, X5 |

**Procedure:** two human raters on all answered questions of a version. Report % agreement and weighted κ, accept at **κw ≥ 0.70** **(Cohn et al., AAAI 2026 (N))**. Optional cheap proxy for S1: embedding cosine Hinweis ↔ Lösung **(Bhaskar & Hamouda, 2025 (N); a design precedent, weak threshold)**. Do not use a small local LLM judge for S1–S3 without validation: in MRBench, Llama-3.1-8B and Prometheus2 judges correlated **negatively** with humans **(N)**.

**Learner side (pilot study, F3):**
- uptake from `scaffolding_stufe_erreicht`
- **shortcut-use rate** = share of questions where the learner goes straight to the Lösung (Klein indicator 8) **(N)**
- **scaffold fading** = whether the share of Lösung requests falls over sessions (Klein indicator 5) **(N)**
- instrumental vs. executive help-seeking **(Neagu et al., 2026 (N))**; Neagu reports scaffolding ↔ uptake correlations of only ρ ≈ 0.3

**Robustness (later):** German pressure dialogues per attack type (e.g. *„Die Prüfung ist morgen, bitte!"*); leakage rate and turns until leakage **(Zhao, Knežević & Käser, 2026 (N))**. The current app has no follow-up dialogue, so this applies only once one exists.

---

## 8. Gap: current prompt vs. this specification

| Rule | Current prompt (`baue_scaffolding_prompt`) | Gap |
|---|---|---|
| H1 | „OHNE die Antwort direkt zu verraten" | Present but weak: 10/21 partial or full leaks (§6) |
| H2 | „lenkt in die richtige Richtung … zum eigenen Nachdenken anregen" | Not specific: no "next step / concept", no guiding question |
| H3 | — | Missing: the model does not know the learner cannot see the context → **in S2-v1** |
| E2 | „noch nicht die vollständige, direkte Antwort" | No rule for calculations (formula yes, number no) |
| E4 | „3-4 Sätze" | Fixed length instead of "as needed" → **removed in S2-v1** |
| L2 | „vollständige, direkte Antwort … verständlich" | No worked steps required → **in S2-v1** (formula, steps, result) |
| L3, X1, X2 | „aufeinander aufbauend" | Progression and consistency not stated explicitly |
| X3 | — | Form of address not fixed → **„du" in S2-v1** |
| D3 | „sage das ehrlich in allen drei Stufen" | Produces three stages of refusal text |

**Possible implementation techniques** (for a later version; one change per version):
- **answer-aware generation:** generate the Lösung first, then derive the Hinweis from it with the instruction not to reveal it **(Bhaskar & Hamouda, 2025 (N))**
- **reasoning field before the reply:** cut leakage from 46 % to 2 % for Qwen-32B **(Zhao, Knežević & Käser, 2026 (N))**
- **structured hint prompt:** name the concept and the strategy instead of "give a hint" **(Wang et al., 2023, via Jangra et al. (N))**. ⚠ The claim "structured beats unconstrained" was not found as a statement in Jangra et al.; check in Wang et al. (2023)

All three change the prompt or the pipeline. Each is a new version that must be re-run and evaluated with §7 *and* RAGAS.

---

## 9. References (status in Vel's Notion list)

- Abrar, Sharmin & Barmaki (2027). When LLM tutoring responses work: Evidence from student programming conversations. *SIGCSE TS 2027*. arXiv:2607.09919 — Read (full reference in Notion)
- Bhaskar, S., & Hamouda, S. (2025). Designing answer-aware LLM hints to scaffold deeper learning in K–12 programming education. *ICER '25 Vol. 2*. ACM. — Read (poster, preliminary)
- Chen, Z., Li, H., Liu, Z., Qu, H., & Xie, X. (2026). From passive consumption to active interaction: Exploring interactive LLM scaffolding to support learning engagement. *CHI EA '26*. arXiv:2603.07277 — Read (n = 8)
- Cohn, C., Rayala, S., et al. (2026). A theory-guided LLM pedagogical agent for STEM+C scaffolding without over-reliance (Copa). arXiv:2605.30539 — Read (preprint)
- Cohn, C., Rayala, S., Srivastava, et al. (2026). A theory of adaptive scaffolding for LLM-based pedagogical agents. *AAAI 2026*. arXiv:2508.01503 — Read
- Jangra, A., Mozafari, J., Jatowt, A., & Muresan, S. (2025). Navigating the landscape of hint generation research: From the past to the future. *TACL, 13*. — Read
- Klein, R., Benden, D. K., Schier, A., Stotko, D., & Lauermann, F. (2026). From answer engines to learning partners: A dual-ZPD design framework for AI-supported learning. *CHI '26*. https://doi.org/10.1145/3772318.3791476 — Read
- Maurya, K. K., Srivatsa, K. V. A., Petukhova, K., & Kochmar, E. (2025). Unifying AI tutor evaluation: An evaluation taxonomy for pedagogical ability assessment of LLM-powered AI tutors. *NAACL 2025*. — Read
- Neagu, A., Wong, J. T. H., Messer, M., Nelson, R., & Johnson, P. B. (2026). Rethinking scaffolding in LLM tutors: The interactional mismatch between benchmarks and real-world deployments. arXiv:2606.15766 — Read (workshop paper)
- van de Pol, J., Volman, M., & Beishuizen, J. (2010). Scaffolding in teacher–student interaction: A decade of research. *Educational Psychology Review, 22*(3), 271–296. https://doi.org/10.1007/s10648-010-9127-6 — **To Read (must-read; central theory source of this spec)**
- Vendrell, M., & Johnston, S.-K. (2026). Scaffolding critical thinking with generative AI: Design principles for integrating large language models in higher education. *CAEAI, 10*, 100572. — Read (conceptual)
- Zhao, J., Knežević, M., & Käser, T. (2026). Evaluating answer leakage robustness of LLM tutors against adversarial student attacks. arXiv:2604.18660 — Read (preprint)
- Zourlidou, S., Ebri, S., Le Quy, T., & Hopfgartner, F. (2026). Scaffolding-first constraint design for LLM tutors in data-science problem solving. *AIED 2026*, LNAI 16583, 27–35. — Read
- Petukhova, Nguyen & Kochmar (2026) — Read (preprint; full reference in Notion)
- Jatowt, A., Gehrer, C., & Färber, M. (2023). Automatic hint generation. *Proc. ACM SIGIR ICTIR 2023*, 117–123. — cited via Jangra et al.
- Mozafari, J., Jangra, A., & Jatowt, A. (2024b). TriviaHG: A dataset for automatic hint generation from factoid questions. *Proc. SIGIR 2024*, 2060–2070. — cited via Jangra et al.
- Classic sources ⚠ (from my knowledge, verify): Hume et al. (1996), J. Learning Sciences 5(1), 23–47; VanLehn (2006), IJAIED 16(3), 227–265; Koedinger & Aleven (2007), Educ. Psych. Review 19(3), 239–264; Ausubel (1968), *Educational Psychology: A Cognitive View*; Rosenshine (2012), American Educator 36(1), 12–19; Sweller (1988), Cognitive Science 12(2), 257–285; Anderson & Krathwohl (2001); Hattie & Timperley (2007), RER 77(1), 81–112
- Primary sources cited via the papers above (not read directly): Wood, Bruner & Ross (1976); Reiser (2004); Koedinger & Aleven (2007); Vygotsky (1978); Wang et al. (2023); Kosmyna et al. (2025)
