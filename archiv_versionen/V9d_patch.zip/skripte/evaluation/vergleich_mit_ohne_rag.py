"""
vergleich_mit_ohne_rag.py
-------------------------
Einmaliger Vergleich: dasselbe Modell (qwen3.5:9b, T=0, Seed 42) beantwortet dieselben Fragen
  OHNE RAG  - nur die Frage, Prompt O-v1 (Fachlehrkraft, knapp, Rechenweg, "sag, wenn du unsicher bist")
  MIT RAG   - volle Pipeline (Retrieval + aktuelle Prompt-Version, inkl. Hinweis-Prüfung);
              bewertet wird die LÖSUNG (Stufe 3), wie in ragas_auswertung.py.

Fragen: 29 Testfragen Fischer (mit erwarteter Kernaussage als Referenz) + 4 Tabellenfragen T1-T4
aus testideen_fischer_v1.csv (Referenz = die "richtig"-Idee). Zusammen 33.

Bewertung gegen die Referenz durch einen Richter (Standard mistral-nemo, NICHT der Generator),
Prompt K-v1: KORREKT / TEILWEISE / FALSCH / VERWEIGERT + ein Satz Begründung.
Fragen vom Typ "ausserhalb" (nicht im Buch) werden nicht vom Richter bewertet, sondern nur
danach eingeteilt, ob das Modell verweigert oder aus Allgemeinwissen antwortet.

Wichtig für die Deutung:
  - Die Referenz ist das LEHRBUCH (Stand 2019). Eine Antwort ohne RAG kann fachlich vertretbar
    sein und trotzdem von der Referenz abweichen (z. B. Wirkungsgrad Fotovoltaik heute).
    Dafür gibt es die Handspalte hand_ohne / hand_mit und anmerkung.
  - Der Richter ist ungeprüft (neuer Prompt K-v1) -> Stichprobe von Hand prüfen.

Ausgabe (enthält Buchinhalte -> nicht ins Git, siehe .gitignore-Zeile in der Anleitung):
  evaluationsdaten/vergleich_rag_<SITZUNG>.csv
  evaluationsdaten/vergleich_rag_<SITZUNG>_zusammenfassung.txt

Start (Ollama läuft, Umgebung pilot_rag):
  python skripte/evaluation/vergleich_mit_ohne_rag.py RAGVGL-FISCHER \
      --kb daten/wissensbasen/knowledge_base_fischer_v7c.json --retrieval hybrid_kg_rr
  --limit 3         nur die ersten 3 Fragen (Probelauf)
  --judge none      ohne Richter (nur Antworten erzeugen)
Dauer grob 35-45 min (ohne RAG ~10 s/Frage, mit RAG ~45 s/Frage, Richter ~5 s/Antwort).
"""
import sys as _sys, pathlib as _pl  # Projektpfade (lernassistent/pfadsetup.py)
_sys.path.insert(0, str(next(p for p in _pl.Path(__file__).resolve().parents if (p / "lernassistent").is_dir()) / "lernassistent")); import pfadsetup  # noqa: E402,F401

import argparse
import collections
import csv
import re
import time
from pathlib import Path

import rag_pipeline as rp
from ragas_auswertung import ist_modell_verweigerung

OHNE_RAG_PROMPT_VERSION = "O-v1"
RICHTER_PROMPT_VERSION = "K-v1"
RICHTER_OPTIONEN = {"temperature": 0, "seed": 42}
URTEILE = ("KORREKT", "TEILWEISE", "FALSCH", "VERWEIGERT")

FELDER = ["nr", "typ", "frage", "referenz",
          "antwort_ohne", "urteil_ohne", "begruendung_ohne", "sek_ohne",
          "status_mit", "antwort_mit", "urteil_mit", "begruendung_mit", "sek_mit", "quellen_mit",
          "rechen_pruefung_mit", "rechen_befund_mit", "rechenfehler_ohne",
          "hand_ohne", "hand_mit", "anmerkung"]


def prompt_ohne_rag(frage):
    return (
        "Du bist Fachlehrkraft für Elektrotechnik in der beruflichen Ausbildung. "
        "Beantworte die Frage einer oder eines Auszubildenden fachlich korrekt und knapp "
        "(höchstens 6 Sätze). Bei Rechenaufgaben: Formel, eingesetzte Werte, Ergebnis mit Einheit. "
        "Wenn du etwas nicht sicher weißt, sage das ausdrücklich, statt zu raten.\n\n"
        f"Frage: {frage}\n\nAntwort:"
    )


def prompt_richter(frage, referenz, antwort):
    return (
        "Du prüfst die Antwort auf eine Fachfrage gegen eine Referenz aus einem Lehrbuch.\n\n"
        f"Frage: {frage}\n\n"
        f"Referenz (Lehrbuch): {referenz}\n\n"
        f"Antwort: {antwort}\n\n"
        "Bewerte NUR den fachlichen Inhalt im Vergleich zur Referenz:\n"
        "KORREKT: Die Antwort enthält die Kernaussage der Referenz und widerspricht ihr nicht.\n"
        "TEILWEISE: Ein Teil stimmt, aber wesentliche Teile der Referenz fehlen oder ein Teil widerspricht ihr.\n"
        "FALSCH: Die Kernaussage fehlt oder widerspricht der Referenz (auch falscher Wert, falsche Einheit, Rechenfehler).\n"
        "VERWEIGERT: Die Antwort lehnt ab oder sagt, dass die Information fehlt.\n"
        "Zusätzliche richtige Informationen sind kein Fehler. Prüfe Zahlen, Einheiten und Rechnungen genau.\n\n"
        "Antworte genau in zwei Zeilen:\n"
        "URTEIL: <KORREKT|TEILWEISE|FALSCH|VERWEIGERT>\n"
        "BEGRÜNDUNG: <ein Satz>"
    )


_URTEIL = re.compile(r"URTEIL\W*:?\W*(KORREKT|TEILWEISE|FALSCH|VERWEIGERT)", re.I)
_BEGR = re.compile(r"BEGR(?:Ü|UE)NDUNG\W*:\s*(.+)", re.I | re.S)
_UNSICHER = re.compile(r"\b(weiß ich nicht|nicht sicher|kann ich nicht (?:sicher )?(?:sagen|beantworten)|"
                       r"keine (?:aktuellen |verlässlichen )?(?:informationen|daten))\b", re.I)


def richte(frage, referenz, antwort, modell):
    roh = rp.frage_llm(prompt_richter(frage, referenz, antwort), model=modell, options=RICHTER_OPTIONEN)
    u = _URTEIL.search(roh)
    b = _BEGR.search(roh)
    return (u.group(1).upper() if u else "FORMATFEHLER"), (b.group(1).strip().splitlines()[0] if b else roh[:200])


def lade_fragen(fragen_pfad, ideen_pfad):
    fragen = []
    with open(fragen_pfad, encoding="utf-8") as f:
        for r in csv.DictReader(f):
            fragen.append({"nr": r["nr"], "typ": r["typ"], "frage": r["frage"],
                           "referenz": r["erwartete_kernaussage"]})
    if ideen_pfad and Path(ideen_pfad).exists():
        with open(ideen_pfad, encoding="utf-8") as f:
            for r in csv.DictReader(f):
                if r["frage_id"].startswith("T") and r["ideen_typ"] == "richtig":
                    fragen.append({"nr": r["frage_id"], "typ": "tabelle", "frage": r["frage"],
                                   "referenz": r["idee"]})
    return fragen


def schreibe(pfad, zeilen):
    with open(pfad, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=FELDER)
        w.writeheader()
        for z in zeilen:
            w.writerow({k: z.get(k, "") for k in FELDER})


def main():
    ap = argparse.ArgumentParser()
    ap.add_argument("sitzung")
    ap.add_argument("--kb", default="daten/wissensbasen/knowledge_base_fischer_v7c.json")
    ap.add_argument("--fragen", default="daten/testfragen/testfragen_fischer_v1.csv")
    ap.add_argument("--ideen", default="daten/testfragen/testideen_fischer_v1.csv",
                    help="Quelle der Tabellenfragen T1-T4 ('' = weglassen)")
    ap.add_argument("--retrieval", default="hybrid_kg_rr")
    ap.add_argument("--judge", default="mistral-nemo", help="Richter-Modell oder 'none'")
    ap.add_argument("--limit", type=int, default=None)
    args = ap.parse_args()

    chunks = rp.lade_wissensbasis(args.kb)
    kb_hash = rp.berechne_kb_hash(args.kb)
    fragen = lade_fragen(args.fragen, args.ideen)[: args.limit]
    out = Path("evaluationsdaten") / f"vergleich_rag_{args.sitzung}.csv"
    konfig = (f"Generator {rp.MODEL_NAME} {rp.GENERIERUNGS_OPTIONEN}; ohne RAG: {OHNE_RAG_PROMPT_VERSION}; "
              f"mit RAG: {rp.SCAFFOLDING_VERSION}/{rp.RECHEN_PRUEFUNG_VERSION}/{rp.HINWEIS_PRUEFUNG_VERSION}, "
              f"Retrieval {args.retrieval}, "
              f"KB {args.kb} ({kb_hash}); Richter {args.judge} ({RICHTER_PROMPT_VERSION})")
    print(f"{len(fragen)} Fragen | {konfig}\n")

    # Phase 1+2: erst alle Antworten mit qwen (kein Modellwechsel pro Frage), dann der Richter
    zeilen = []
    for q in fragen:
        z = dict(q)
        t0 = time.time()
        z["antwort_ohne"] = rp.frage_llm(prompt_ohne_rag(q["frage"]), options=rp.GENERIERUNGS_OPTIONEN)
        z["sek_ohne"] = round(time.time() - t0, 1)
        t0 = time.time()
        erg = rp.beantworte_frage(q["frage"], chunks, methode=args.retrieval)
        z["sek_mit"] = round(time.time() - t0, 1)
        z["status_mit"] = erg.get("status", "")
        z["antwort_mit"] = erg.get("loesung", "")
        z["quellen_mit"] = "; ".join(c["id"] for c in erg.get("quellen", []))
        z["rechen_pruefung_mit"] = erg.get("rechen_pruefung", "")
        z["rechen_befund_mit"] = erg.get("rechen_befund", "")
        import rechenpruefung  # nur Diagnose: dieselbe Nachrechnung für die Antwort ohne RAG
        z["rechenfehler_ohne"] = "; ".join(b["text"] for b in rechenpruefung.pruefe_rechnungen(z["antwort_ohne"]))
        print(f"[{q['nr']:>3}] {q['typ']:<12} ohne {z['sek_ohne']:>5.0f} s | mit {z['sek_mit']:>5.0f} s "
              f"{z['status_mit']}")
        zeilen.append(z)
        schreibe(out, zeilen)  # Zwischenstand, falls der Lauf abbricht

    if args.judge.lower() != "none":
        print(f"\nRichter {args.judge} ...")
    for z in zeilen:
        for seite in ("ohne", "mit"):
            antwort = z[f"antwort_{seite}"]
            verweigert = (ist_modell_verweigerung(antwort)
                          or (seite == "mit" and z["status_mit"] in ("NICHT_IM_MATERIAL", "GATE")))
            if z["typ"] == "ausserhalb":
                z[f"urteil_{seite}"] = "VERWEIGERT" if verweigert else "BEANTWORTET_OHNE_BUCH"
                z[f"begruendung_{seite}"] = "(nicht im Buch; kein Richter)"
            elif verweigert:
                z[f"urteil_{seite}"], z[f"begruendung_{seite}"] = "VERWEIGERT", "(Verweigerung erkannt)"
            elif args.judge.lower() == "none":
                z[f"urteil_{seite}"] = ""
            else:
                z[f"urteil_{seite}"], z[f"begruendung_{seite}"] = richte(z["frage"], z["referenz"], antwort, args.judge)
        if z["typ"] != "ausserhalb" and _UNSICHER.search(z["antwort_ohne"]):
            z["anmerkung"] = "(ohne RAG: äußert Unsicherheit)"
        if args.judge.lower() != "none":
            print(f"[{z['nr']:>3}] ohne {z['urteil_ohne']:<22} mit {z['urteil_mit']}")
    schreibe(out, zeilen)

    # Zusammenfassung
    zeilen_txt = [konfig, ""]
    gruppen = collections.OrderedDict([("im Buch (Richter)", lambda z: z["typ"] != "ausserhalb"),
                                       ("davon rechnung", lambda z: z["typ"] == "rechnung"),
                                       ("davon tabelle", lambda z: z["typ"] == "tabelle"),
                                       ("davon abbildung", lambda z: z["typ"] == "abbildung"),
                                       ("davon konzept", lambda z: z["typ"] == "konzept"),
                                       ("davon teilrelevant", lambda z: z["typ"] == "teilrelevant"),
                                       ("ausserhalb des Buchs", lambda z: z["typ"] == "ausserhalb")])
    for name, filt in gruppen.items():
        auswahl = [z for z in zeilen if filt(z)]
        if not auswahl:
            continue
        for seite in ("ohne", "mit"):
            c = collections.Counter(z[f"urteil_{seite}"] for z in auswahl)
            zeilen_txt.append(f"{name:<22} {seite:<4} n={len(auswahl):>2}  " +
                              "  ".join(f"{k} {v}" for k, v in c.most_common()))
    for seite in ("ohne", "mit"):
        sek = [z[f"sek_{seite}"] for z in zeilen]
        zeilen_txt.append(f"Antwortzeit {seite}: Median {sorted(sek)[len(sek) // 2]:.0f} s")
    paare = collections.Counter((z["urteil_ohne"], z["urteil_mit"]) for z in zeilen if z["typ"] != "ausserhalb")
    zeilen_txt.append("\nPaare (ohne -> mit), nur Fragen im Buch:")
    zeilen_txt += [f"  {a:<12} -> {b:<12} {n}" for (a, b), n in paare.most_common()]
    text = "\n".join(zeilen_txt)
    rpm = collections.Counter(z.get("rechen_pruefung_mit", "") for z in zeilen)
    text += f"\nRechenprüfung mit RAG: {dict(rpm)}; Rechenfehler ohne RAG (nur Diagnose): " \
            f"{sum(bool(z.get('rechenfehler_ohne')) for z in zeilen)}"
    print("\n=== Zusammenfassung (Richter-Urteile, von Hand prüfen) ===\n" + text)
    out.with_name(out.stem + "_zusammenfassung.txt").write_text(text + "\n", encoding="utf-8")
    print(f"\nDatei für die Handprüfung: {out}")


if __name__ == "__main__":
    main()
