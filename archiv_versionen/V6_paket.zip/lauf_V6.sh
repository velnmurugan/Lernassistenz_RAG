#!/usr/bin/env bash
# V6: fester Prompt-Satz (G-v1 / IF-v2 / J-v1) auf beiden Testsätzen + V4 mit J-v1 neu bewerten.
# Vorher: Fischer-PDF nach quellmaterial_fischer/ kopieren. Dauer: grob 1,5–3 h.
# Start:  bash lauf_V6.sh 2>&1 | tee lauf_V6.txt
export HF_HUB_OFFLINE=1 TRANSFORMERS_OFFLINE=1
RET="--retrieval hybrid_kg_rr --rrf-k 5"

echo "=== 1/6 Zweite Wissensbasis (Fischer) ==="
[ -f knowledge_base_fischer.json ] || python -u baue_zweite_wissensbasis.py quellmaterial_fischer knowledge_base_fischer.json
python -u ordne_chunks_zu.py testfragen_fischer_v1.csv knowledge_base_fischer.json

echo "=== 2/6 Generierung Böge (V6-BOEGE) ==="
python -u fuehre_testfragen_aus.py V6-BOEGE $RET --scaffolding G-v1

echo "=== 3/6 Generierung Fischer (V6-FISCHER) ==="
python -u fuehre_testfragen_aus.py V6-FISCHER $RET --scaffolding G-v1 \
    --kb knowledge_base_fischer.json --fragen testfragen_fischer_v1_chunks.csv

ollama stop qwen3.5:9b

echo "=== 4/6 RAGAS Böge ==="
python -u ragas_auswertung.py V6-BOEGE && python archiviere_version.py V6-BOEGE

echo "=== 5/6 RAGAS Fischer ==="
python -u ragas_auswertung.py V6-FISCHER --kb knowledge_base_fischer.json && python archiviere_version.py V6-FISCHER

echo "=== 6/6 V4 mit Richter-Prompts J-v1 neu bewerten (Antworten bleiben gleich) ==="
python -u ragas_auswertung.py V4-S2 --judge-prompts J-v1 && python archiviere_version.py V4-S2 V4-S2_J-v1

echo "=== Stufen-Check ==="
python stufen_check.py V4-S2 V6-BOEGE V6-FISCHER
echo "=== fertig ==="
