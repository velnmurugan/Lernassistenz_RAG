"""
rag_pipeline.py
----------------
Kernlogik des KI-Lernassistenten (Pilotstudie, Phase 2 nach Design-Based
Research, siehe Reeves 2006 / Design-Based Research Collective 2003).

Diese Version ist für die Nutzung durch Auszubildende in einer kontrollierten
Evaluation gedacht — NICHT mehr für Demo-Zwecke. Entsprechend wurden alle
"unter die Haube schauen"-Funktionen (Chunking-Demo, PDF-Upload, TF-IDF-
Vergleich, Embedding-Visualisierung) entfernt: Alle Proband:innen sollen
exakt dieselbe, kontrollierte Wissensbasis nutzen — das ist eine bewusste
Entscheidung zur internen Validität der Studie, nicht eine technische
Einschränkung.

Jede wesentliche Design-Entscheidung ist unten mit einer Quelle referenziert.
Eine konsolidierte Übersicht steht zusätzlich in
Design_Entscheidungen_Literatur.md.
"""

import hashlib
import json
import os
import pickle
import re
import subprocess
import csv
import datetime
from pathlib import Path

import numpy as np
import requests
from sklearn.metrics.pairwise import cosine_similarity

MODEL_NAME = "qwen3.5:9b"


# =============================================================================
# Verbindung zum lokalen LLM (Ollama)
# =============================================================================
def _kandidaten_hosts():
    """Mögliche Ollama-Adressen, siehe WSL-Netzwerk-Hinweis in README."""
    kandidaten = []
    manuell = os.environ.get("OLLAMA_HOST")
    if manuell:
        kandidaten.append(manuell)
    kandidaten.append("localhost")
    try:
        result = subprocess.run(["ip", "route"], capture_output=True, text=True, timeout=2)
        for zeile in result.stdout.splitlines():
            if zeile.startswith("default"):
                kandidaten.append(zeile.split()[2])
                break
    except Exception:
        pass
    return kandidaten


def _finde_funktionierenden_host():
    for host in _kandidaten_hosts():
        try:
            r = requests.get(f"http://{host}:11434", timeout=1.5)
            if r.status_code == 200:
                return host
        except requests.exceptions.RequestException:
            continue
    return "localhost"


_OLLAMA_HOST = _finde_funktionierenden_host()
OLLAMA_URL = f"http://{_OLLAMA_HOST}:11434/api/generate"


# =============================================================================
# Wissensbasis-Aufbau aus echten PDF-Quellen (Offline-Werkzeug für die
# Forscherin/den Forscher, NICHT Teil der Studien-App selbst)
# =============================================================================
# Wichtig: Diese Funktionen werden von baue_wissensbasis.py genutzt, um
# EINMALIG, vor Beginn der Studie, aus echten curricularen PDFs eine feste
# Wissensbasis zu erzeugen. Studierende laden selbst keine PDFs hoch — das
# würde die Anforderung "identische Wissensbasis für alle Proband:innen"
# verletzen (siehe Design_Entscheidungen_Literatur.md, Punkt 4).
def lese_pdf_text(pfad):
    """Extrahiert reinen Text aus einer PDF-Datei, Seite für Seite."""
    from pypdf import PdfReader
    reader = PdfReader(pfad)
    seiten_texte = [seite.extract_text() or "" for seite in reader.pages]
    return "\n\n".join(seiten_texte), len(reader.pages)


def lese_pdf_gliederung(reader):
    """
    Extrahiert die im PDF eingebettete Gliederung (Bookmarks/Outline) als
    flache Liste von (Titel, Seitennummer), aufsteigend nach Seite sortiert.

    Wichtig für umfangreiche Fachbücher (z. B. ein Springer-Handbuch), die
    ein einzelnes Dokument sind, aber viele unterschiedliche Themen
    abdecken: Ohne Gliederungserkennung würde der gesamte Inhalt fälschlich
    EIN Thema (den Dateinamen) erhalten. Fachbücher aus wissenschaftlichen
    Verlagen enthalten praktisch immer eine navigierbare Gliederung im
    PDF selbst — diese wird hier statt des Dateinamens als Themenquelle
    genutzt. Das entspricht dem in der ursprünglichen Chunking-Dokumentation
    bereits als Ziel benannten "semantischen/abschnittsbasierten Chunking"
    (siehe chunke_text-Docstring), hier umgesetzt über die vom Verlag
    bereits vorhandene Struktur statt über eigene NLP-Heuristiken.
    """
    eintraege = []

    def durchlaufe(liste):
        for item in liste:
            if isinstance(item, list):
                durchlaufe(item)
            else:
                try:
                    seite = reader.get_destination_page_number(item) + 1  # 1-indiziert
                    titel = str(item.title).strip()
                    if titel:
                        eintraege.append((titel, seite))
                except Exception:
                    continue

    try:
        if reader.outline:
            durchlaufe(reader.outline)
    except Exception:
        pass

    eintraege.sort(key=lambda x: x[1])
    return eintraege


def thema_fuer_seite(seiten_nr, gliederung, fallback_thema):
    """Gibt den Titel des letzten Gliederungseintrags zurück, dessen
    Seite <= seiten_nr ist (d. h. das Kapitel/den Abschnitt, in dem sich
    diese Seite befindet). Fällt auf fallback_thema zurück, wenn keine
    Gliederung vorhanden ist oder die Seite vor dem ersten Eintrag liegt."""
    passende = [titel for titel, s in gliederung if s <= seiten_nr]
    return passende[-1] if passende else fallback_thema


def verarbeite_pdf_seitenweise(datei, max_saetze_pro_chunk, fallback_thema, methode="semantisch",
                                aehnlichkeits_schwelle=0.55, ueberlapp_saetze=1):
    """
    Verarbeitet eine PDF seitenweise: extrahiert Text pro Seite, ordnet
    jede Seite über die Gliederung ihrem Kapitel/Abschnitt zu, chunked den
    Seiteninhalt separat. Rückgabe: (chunks_ohne_id, anzahl_seiten,
    gliederung, hat_gliederung).

    methode="semantisch" (Standard): automatische, inhaltsbasierte
    Chunk-Grenzen über Embedding-Ähnlichkeit (siehe
    chunke_text_semantisch) — keine geratene Satzanzahl nötig.
    methode="fest": einfaches Chunking mit fester Satzanzahl
    (siehe chunke_text) als schnellere, aber gröbere Alternative.

    ueberlapp_saetze: Sätze, die am Ende eines Chunks auch am Anfang des
    nächsten wiederholt werden (siehe _gruppen_zu_chunks, Modran 2025).
    Mindert (löst aber NICHT vollständig) das eigene Testbefund-Muster,
    dass mehrschrittige Rechenbeispiele über mehrere Chunks fragmentiert
    werden — wirkt nur INNERHALB einer Seite, nicht über Seitengrenzen
    hinweg (siehe Trade-off unten).

    Seitenweises statt dokumentweites Chunking ist hier bewusst gewählt,
    damit jeder Chunk zuverlässig einer einzelnen Seite und damit einem
    eindeutigen Thema zugeordnet werden kann. Trade-off: Sätze, die exakt
    auf einem Seitenumbruch geteilt sind, können an der Seitengrenze leicht
    unsauber getrennt werden — für ein mehrere hundert Seiten umfassendes
    Handbuch ist die zuverlässige Themenzuordnung wichtiger als diese
    seltene Randunsauberkeit.
    """
    from pypdf import PdfReader
    reader = PdfReader(datei)
    gliederung = lese_pdf_gliederung(reader)
    hat_gliederung = len(gliederung) > 0

    alle_chunks = []
    for seiten_nr, seite in enumerate(reader.pages, start=1):
        text = seite.extract_text() or ""
        if not text.strip():
            continue
        thema = thema_fuer_seite(seiten_nr, gliederung, fallback_thema) if hat_gliederung else fallback_thema
        if methode == "semantisch":
            seiten_chunks = chunke_text_semantisch(
                text, aehnlichkeits_schwelle=aehnlichkeits_schwelle, max_saetze_pro_chunk=max_saetze_pro_chunk,
                ueberlapp_saetze=ueberlapp_saetze,
            )
        else:
            seiten_chunks = chunke_text(text, max_saetze_pro_chunk=max_saetze_pro_chunk, ueberlapp_saetze=ueberlapp_saetze)
        for c in seiten_chunks:
            if len(c["text"]) < 25:
                continue
            alle_chunks.append({"thema": thema, "text": c["text"], "seite": seiten_nr})

    return alle_chunks, len(reader.pages), gliederung, hat_gliederung


ABKUERZUNGEN = [
    "Univ.-Prof.", "apl. Prof.", "Prof.", "Dr.", "PD", "StD", "SR", "SD",
    "bzw.", "ca.", "z.B.", "u.a.", "usw.", "Nr.", "Str.", "geb.",
    "Ing.", "etc.", "vgl.", "Abs.", "Art.", "Kap.", "Hrsg.",
]
_PLATZHALTER = "\x00"


def _satzsplit(rohtext):
    """Zerlegt Text in Sätze, mit Schutz bekannter Abkürzungen (siehe
    Phase-1-Erkenntnis: "Prof. Dr. Bernd Zinn" wurde ohne diesen Schutz
    in drei Fragmente zerrissen)."""
    rohtext = rohtext.strip()
    geschuetzt = rohtext
    for abk in ABKUERZUNGEN:
        geschuetzt = geschuetzt.replace(abk, abk.replace(".", _PLATZHALTER))
    saetze = re.split(r'(?<=[.!?])\s+', geschuetzt)
    return [s.replace(_PLATZHALTER, ".").strip() for s in saetze if s.strip()]


def _gruppen_zu_chunks(gruppen, ueberlapp_saetze=0):
    """
    Wandelt rohe Satzgruppen in fertige Chunk-Dicts um und fügt dabei
    optional Überlappung zwischen aufeinanderfolgenden Chunks ein: die
    letzten 'ueberlapp_saetze' Sätze des vorherigen Chunks werden dem
    nächsten Chunk vorangestellt.

    Begründung/Quelle: Modran, H. A. (2025). Leveraging RAG with ACP & MCP
    for Adaptive Intelligent Tutoring — nutzt chunk_size=1200 Tokens mit
    overlap=200 Tokens. Wir übertragen dasselbe Prinzip auf unsere
    satzbasierte Chunking-Einheit statt auf Token-Zählung. Zweck: ein
    Fakt, der exakt an einer Chunk-Grenze liegt, verschwindet dadurch
    nicht vollständig, sondern erscheint in BEIDEN benachbarten Chunks —
    direkte Gegenmaßnahme gegen das eigene Testbefund-Muster (mehrschrittige
    Rechenbeispiele werden über mehrere Chunks fragmentiert, siehe
    Design_Entscheidungen_Literatur.md, Punkt 14).

    Wichtig: löst NICHT das Seitengrenzen-Problem (Chunks werden weiterhin
    nie über Seiten hinweg gebildet, siehe verarbeite_pdf_seitenweise) —
    wirkt nur INNERHALB einer Seite zwischen benachbarten Chunks.
    """
    if not gruppen:
        return []

    chunks = []
    for i, gruppe in enumerate(gruppen):
        if ueberlapp_saetze > 0 and i > 0:
            vorherige_gruppe = gruppen[i - 1]
            n = min(ueberlapp_saetze, len(vorherige_gruppe))
            ueberlappende_saetze = vorherige_gruppe[-n:] if n > 0 else []
            volle_gruppe = ueberlappende_saetze + gruppe
        else:
            volle_gruppe = gruppe
        chunks.append({"text": " ".join(volle_gruppe), "anzahl_saetze": len(volle_gruppe)})
    return chunks


def chunke_text(rohtext, max_saetze_pro_chunk=3, ueberlapp_saetze=1):
    """
    Satzbasiertes Chunking mit FESTER Satzanzahl pro Chunk. Einfach und
    schnell, aber die Chunk-Grenzen sind willkürlich (Satz 3 und Satz 4
    können thematisch stärker zusammengehören als Satz 2 und 3, werden
    aber trotzdem getrennt). Für neue Wissensbasis-Erstellung wird daher
    standardmäßig chunke_text_semantisch() empfohlen (siehe dort); diese
    Funktion bleibt als einfachere Alternative und für Abwärtskompatibilität
    erhalten.

    ueberlapp_saetze: siehe _gruppen_zu_chunks — Standardwert 1 statt 0,
    damit Grenzfälle abgefedert werden, ohne die einfache Methode
    grundlegend zu verändern.
    """
    saetze = _satzsplit(rohtext)
    gruppen = [saetze[i:i + max_saetze_pro_chunk] for i in range(0, len(saetze), max_saetze_pro_chunk)]
    return _gruppen_zu_chunks(gruppen, ueberlapp_saetze=ueberlapp_saetze)


def _segmentiere_nach_aehnlichkeit(saetze, aehnlichkeiten, schwelle, max_saetze_pro_chunk, min_saetze_pro_chunk):
    """
    Reine Segmentierungslogik (ohne Embedding-Berechnung), bewusst als
    eigene Funktion, damit sie ohne Embedding-Modell testbar ist.

    aehnlichkeiten[i] = Kosinus-Ähnlichkeit zwischen Satz i und Satz i+1.
    Fällt die Ähnlichkeit unter 'schwelle', wird das als thematischer
    Bruch gewertet und ein neuer Chunk begonnen. max_saetze_pro_chunk
    wirkt nur noch als Sicherheitsobergrenze (verhindert einen einzigen
    riesigen Chunk bei durchgehend ähnlichem Text), min_saetze_pro_chunk
    verhindert Ein-Wort-Chunks bei sehr kurzen, thematisch isolierten
    Sätzen (z. B. Überschriften).

    Gibt ROHE Satzgruppen zurück (Liste von Satzlisten), NICHT fertige
    Chunk-Dicts — die Umwandlung inkl. optionaler Überlappung übernimmt
    _gruppen_zu_chunks() (siehe dort), damit dieselbe Überlappungslogik für
    beide Chunking-Methoden (fest/semantisch) einheitlich gilt.
    """
    if not saetze:
        return []

    gruppen = []
    aktuelle_gruppe = [saetze[0]]

    for i in range(1, len(saetze)):
        aehnlichkeit = aehnlichkeiten[i - 1]
        bruch = aehnlichkeit < schwelle or len(aktuelle_gruppe) >= max_saetze_pro_chunk
        if bruch and len(aktuelle_gruppe) >= min_saetze_pro_chunk:
            gruppen.append(aktuelle_gruppe)
            aktuelle_gruppe = [saetze[i]]
        else:
            aktuelle_gruppe.append(saetze[i])

    gruppen.append(aktuelle_gruppe)
    return gruppen


def chunke_text_semantisch(rohtext, aehnlichkeits_schwelle=0.55, max_saetze_pro_chunk=8,
                            min_saetze_pro_chunk=1, ueberlapp_saetze=1):
    """
    Automatisches, inhaltsbasiertes Chunking — Alternative zu chunke_text()
    mit fester Satzanzahl. Statt eine Chunk-Größe zu raten, wird die
    Embedding-Ähnlichkeit zwischen aufeinanderfolgenden Sätzen gemessen;
    ein deutlicher Ähnlichkeitsabfall wird als thematischer Bruch
    interpretiert und dort ein neuer Chunk begonnen.

    Nutzt dasselbe Embedding-Modell, das ohnehin für das Retrieval geladen
    wird — es entsteht kein zusätzliches Modell, nur zusätzliche (einmalige,
    da nur beim Wissensbasis-Aufbau genutzte) Rechenzeit für die
    Satz-Embeddings.

    aehnlichkeits_schwelle=0.55 ist ein Startwert, kein empirisch
    kalibrierter Wert (siehe RELEVANZ_SCHWELLE-Hinweis zur Kalibrierung) —
    beim Wissensbasis-Aufbau mit echtem Material stichprobenartig prüfen,
    ob die entstehenden Chunks inhaltlich sinnvoll wirken, und bei Bedarf
    anpassen.

    ueberlapp_saetze: siehe _gruppen_zu_chunks (Modran 2025-Prinzip,
    Chunk-Grenzen-Überlappung).
    """
    saetze = _satzsplit(rohtext)
    if len(saetze) <= 1:
        return [{"text": s, "anzahl_saetze": 1} for s in saetze]

    modell = _lade_embedding_modell()
    embeddings = modell.encode(saetze, convert_to_numpy=True, normalize_embeddings=True)

    aehnlichkeiten = [
        float(cosine_similarity(embeddings[i:i + 1], embeddings[i + 1:i + 2])[0][0])
        for i in range(len(saetze) - 1)
    ]

    gruppen = _segmentiere_nach_aehnlichkeit(
        saetze, aehnlichkeiten, aehnlichkeits_schwelle, max_saetze_pro_chunk, min_saetze_pro_chunk
    )
    return _gruppen_zu_chunks(gruppen, ueberlapp_saetze=ueberlapp_saetze)


# =============================================================================
# Konfiguration
# =============================================================================
# Relevanz-Schwelle für Embedding-Retrieval. Ein System, das bei fehlender
# Evidenz lieber ablehnt statt zu raten, adressiert direkt das "Tug-of-War"-
# Phänomen (Modell ignoriert Retrieval-Evidenz zugunsten von internem
# Wissen), das Oche et al. (2025, "A Systematic Review of Key
# Retrieval-Augmented Generation (RAG) Systems") als zentrales RAG-Risiko
# beschreiben. Kalibriert empirisch während der Prototyp-Tests (Phase 1).
RELEVANZ_SCHWELLE = 0.35

# Schlüsselwortbasierte Sicherheitsprüfung. Bewusst einfache Version für
# Phase 1/2 (siehe Systemkonzept-Säule "Sicherheit"); eine echte
# Klassifikator-Lösung ist für Phase 3 vorgesehen.
SICHERHEITS_SCHLUESSELWOERTER = [
    
]

EMBEDDING_MODELL_NAME = "paraphrase-multilingual-MiniLM-L12-v2"

# Retrieval-Methode (siehe retrieval()):
#   "dense"  — nur Embeddings (Baseline V0, bisheriges Verhalten der Studien-App)
#   "bm25"   — nur Schlüsselwortsuche
#   "hybrid" — beide Ranglisten per Reciprocal Rank Fusion kombiniert (V1)
#   "graph"  — nur Konzept-Wissensgraph (Personalized PageRank, siehe wissensgraph.py)
#   "hybrid_kg" — dense + BM25 + Wissensgraph per RRF (V2)
#   "<methode>_rr" — Vorstufe <methode>, danach Cross-Encoder-Reranking der besten
#                 Kandidaten (V3: "hybrid_kg_rr"; Kontrolle ohne Graph: "hybrid_rr"), siehe reranker.py
# Die Studien-App nutzt diesen Standard; Testläufe können pro Aufruf eine
# andere Methode übergeben (fuehre_testfragen_aus.py --retrieval ...).
RETRIEVAL_METHODE = "dense"
RRF_K = 5  # Cormack et al. (2009) nutzen 60. V1 (hybrid): k=2 empirisch gewählt (retrieval_vergleich.py,
           # 25 Testfragen; bestes MRR und R@4+Nachbar; bei k=60 schlugen Chunks, die in beiden Listen
           # mittelmäßig rangierten, Chunks auf Spitzenplätzen einer Liste). V2 (hybrid_kg): k=5
           # (R@4 13 vs. 11 bei k=2). Standard = aktuelle Version; V1 nachstellen mit --rrf-k 2.

# Generierungs-Einstellungen für qwen (Studien-App UND Testläufe identisch).
# Ohne feste Werte nutzt Ollama seine Standard-Stichprobe; derselbe Kontext führte
# dann mal zu Verweigerung, mal zu Antwort (Befund V1-HYBRID2 vs. V1-HYBRID2-CLEAN:
# gleiche Retrieval-Ränge, 12 vs. 7 Verweigerungen). temperature=0 + fester seed:
# (1) reproduzierbare Evaluation, (2) inhaltlich gewollt — ein quellengebundener
# Lernassistent soll nicht kreativ variieren. Restvarianz durch GPU-Arithmetik möglich.
GENERIERUNGS_OPTIONEN = {"temperature": 0, "seed": 42}
KG_GEWICHT = 1.0  # Gewicht der Graph-Liste in der RRF-Summe ("hybrid_kg"); 1.0 = gleichrangig
BM25_CACHE_VERZEICHNIS = Path("cache")  # nicht committen (.gitignore)

LOG_VERZEICHNIS = Path("evaluationsdaten")
LOG_VERZEICHNIS.mkdir(exist_ok=True)
INTERAKTIONS_LOG = LOG_VERZEICHNIS / "interaktionen.csv"
FRAGEBOGEN_LOG = LOG_VERZEICHNIS / "fragebogen.csv"


# =============================================================================
# Wissensbasis
# =============================================================================
def lade_wissensbasis(pfad="daten/wissensbasen/knowledge_base_boege.json"):
    """
    Lädt die kuratierte, für ALLE Proband:innen identische Wissensbasis.

    Identische Wissensbasis für alle Teilnehmenden ist eine Grundvoraussetzung
    für die interne Validität eines kontrollierten Vergleichs (Standard in der
    empirischen Bildungsforschung; vgl. auch das methodische Vorgehen bei
    Modran 2025 und Happe et al. 2025, die ebenfalls mit einer festen,
    vorab kuratierten Wissensbasis pro Studiendurchlauf arbeiten).
    """
    with open(pfad, "r", encoding="utf-8") as f:
        daten = json.load(f)
    return daten["chunks"]


def berechne_kb_hash(pfad="daten/wissensbasen/knowledge_base_boege.json"):
    """
    Kurzer Fingerabdruck (SHA-256, erste 12 Zeichen) der Wissensbasis-Datei.
    Wird pro Interaktion protokolliert, damit die spätere RAGAS-Auswertung
    (ragas_auswertung.py) prüfen kann, ob die geloggten Chunk-IDs noch auf
    denselben Text zeigen. Bei Neuaufbau im Modus "ERSETZEN" werden IDs neu
    vergeben — ohne diesen Abgleich würden alte Logs stillschweigend gegen
    falschen Kontext bewertet.
    """
    h = hashlib.sha256()
    with open(pfad, "rb") as f:
        for block in iter(lambda: f.read(1 << 20), b""):
            h.update(block)
    return h.hexdigest()[:12]


# =============================================================================
# Retrieval (Embeddings)
# =============================================================================
# Embedding-basiertes statt wortbasiertes (TF-IDF) Retrieval als alleinige
# Methode im Studien-Prototyp. Begründung:
#   1. Grundlagenarbeit: Reimers & Gurevych (2019), "Sentence-BERT:
#      Sentence Embeddings using Siamese BERT-Networks" — Embeddings
#      erfassen Bedeutung statt reiner Wortoberfläche.
#   2. Eigene empirische Erkenntnis aus Phase 1: TF-IDF versagt bei
#      deutschen Wortformvarianten (z. B. "einfachwirkenden" vs.
#      "einfachwirkender"), was für Auszubildende mit natürlicher,
#      variabler Frageformulierung praxisrelevant ist.
_embedding_modell = None
_chunk_embedding_cache = {}


def _lade_embedding_modell():
    global _embedding_modell
    if _embedding_modell is None:
        from sentence_transformers import SentenceTransformer
        _embedding_modell = SentenceTransformer(EMBEDDING_MODELL_NAME)
    return _embedding_modell


def _embeddings_fuer_chunks(chunks):
    modell = _lade_embedding_modell()
    schluessel = tuple(c["text"] for c in chunks)
    if schluessel not in _chunk_embedding_cache:
        embeddings = modell.encode(list(schluessel), convert_to_numpy=True, normalize_embeddings=True)
        _chunk_embedding_cache[schluessel] = embeddings
    return _chunk_embedding_cache[schluessel]


# -----------------------------------------------------------------------------
# BM25 (Schlüsselwortsuche) — Ergänzung für V1 "hybrid"
# -----------------------------------------------------------------------------
# Begründung: Fachbegriffe (Zweihandverriegelung, D-Anteil, DIN EN 13001-2,
# CNC) sind exakte Wörter, die ein kleines Embedding-Modell "verwischt".
# Eigener Testbefund V0 (TEST-01): Recall@4 nur 6/25, Quell-Chunk oft auf
# Rang > 100. Gegenposition zur ursprünglichen Nur-Embedding-Entscheidung:
# "From BM25 to Corrective RAG" (EACL 2026) — BM25 bei terminologie- und
# tabellenlastigen Dokumenten überlegen. BM25: Robertson & Zaragoza (2009).
BM25_STOPPWOERTER = set("""
aber alle allem allen aller alles als also am an ander andere anderem anderen anderer anderes
auch auf aus bei beim bin bis bist da damit dann das dass dein deine dem den der des dessen die
dies diese diesem diesen dieser dieses doch dort du durch ein eine einem einen einer eines er es
etwa euch euer für gegen hat hatte hätte habe haben hier hin hinter ich ihr ihre im in indem ins
ist ja jede jedem jeden jeder jedes jetzt kann kein keine können könnte man mein meine mich mir
mit muss müssen nach nicht nichts noch nun nur ob oder ohne sehr sein seine sich sie sind so
solche soll sollte sondern um und uns unser unter vom von vor war wäre waren was weil welche
welchem welchen welcher welches wenn wer werden wie wieder will wir wird wo wurde würde zu zum
zur zwar zwischen eigentlich mal
""".split())

_stemmer = None
_bm25_cache = {}


def tokenisiere(text):
    """Für BM25: Silbentrennung aus der PDF-Extraktion zusammenführen
    ("Kurbel-\\numdrehungen" -> "kurbelumdrehungen"), Kleinschreibung,
    Wörter/Zahlen, Stoppwörter entfernen, deutsches Snowball-Stemming
    (damit z. B. "Verriegelung"/"Verriegelungen" zusammenfallen)."""
    global _stemmer
    if _stemmer is None:
        import snowballstemmer
        _stemmer = snowballstemmer.stemmer("german")
    text = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", text)
    woerter = re.findall(r"[a-zäöüß0-9]+", text.lower())
    return _stemmer.stemWords([w for w in woerter if len(w) >= 2 and w not in BM25_STOPPWOERTER])


def _bm25_index(chunks):
    """BM25-Index über alle Chunks. Zwischengespeichert im Speicher (pro
    Prozess) und auf Platte (pro Inhalt der Wissensbasis), weil das
    Tokenisieren von ~32.000 Chunks sonst bei jedem Start ~1 Minute dauert."""
    from rank_bm25 import BM25Okapi
    schluessel = tuple(c["text"] for c in chunks)
    if schluessel not in _bm25_cache:
        fingerabdruck = hashlib.sha256("\x1e".join(schluessel).encode("utf-8")).hexdigest()[:12]
        BM25_CACHE_VERZEICHNIS.mkdir(exist_ok=True)
        datei = BM25_CACHE_VERZEICHNIS / f"bm25_tokens_{fingerabdruck}.pkl"
        if datei.exists():
            with open(datei, "rb") as f:
                korpus = pickle.load(f)
        else:
            korpus = [tokenisiere(t) for t in schluessel]
            with open(datei, "wb") as f:
                pickle.dump(korpus, f)
        _bm25_cache[schluessel] = BM25Okapi(korpus)
    return _bm25_cache[schluessel]


def _raenge(scores):
    """scores -> Rang pro Element (1 = bester), stabil bei Gleichstand."""
    reihenfolge = np.argsort(-scores, kind="stable")
    rang = np.empty(len(scores), dtype=np.int64)
    rang[reihenfolge] = np.arange(1, len(scores) + 1)
    return rang


def retrieval(frage, chunks, top_k=4, methode=None):
    """
    Retrieval mit wählbarer Methode (Standard: RETRIEVAL_METHODE).

    "dense": Embedding-basiert (Reimers & Gurevych 2019), bisheriges Verhalten.
    top_k=4 (statt z. B. 2) reduziert das in Phase 1 beobachtete Risiko, dass
    ein einzelner, kurzer Fakt (z. B. eine konkrete ECTS-Zahl) durch eng
    verwandte, aber nicht antworttragende Passagen verdrängt wird (siehe
    Design_Entscheidungen_Literatur.md, "Retrieval-Vollständigkeit").
    "bm25": reine Schlüsselwortsuche (siehe tokenisiere/_bm25_index).
    "hybrid": Reciprocal Rank Fusion beider Ranglisten, score = Σ 1/(RRF_K + rang)
    (Cormack, Clarke & Büttcher 2009). RRF statt gewichteter Score-Summe, weil
    BM25-Werte und Kosinus-Ähnlichkeiten nicht auf derselben Skala liegen.

    Wichtig: Das Feld "score" jedes Ergebnisses ist IMMER die Kosinus-
    Ähnlichkeit (auch bei bm25/hybrid). Damit bleiben RELEVANZ_SCHWELLE und das
    Feld bester_score im Log zwischen den Varianten identisch definiert — nur
    die Auswahl der Chunks ändert sich (eine Variable pro Version).
    Sortiert wird nach "rangwert" (je nach Methode Kosinus, BM25 oder RRF).
    """
    methode = methode or RETRIEVAL_METHODE
    rerank = methode.endswith("_rr")
    if rerank:
        methode = methode[:-3]
    modell = _lade_embedding_modell()
    chunk_embeddings = _embeddings_fuer_chunks(chunks)
    frage_embedding = modell.encode([frage], convert_to_numpy=True, normalize_embeddings=True)
    dense = cosine_similarity(frage_embedding, chunk_embeddings)[0]

    if methode == "dense":
        rangwert = dense
    elif methode in ("bm25", "hybrid"):
        bm25 = np.asarray(_bm25_index(chunks).get_scores(tokenisiere(frage)), dtype=np.float64)
        if methode == "bm25":
            rangwert = bm25
        else:
            rangwert = 1.0 / (RRF_K + _raenge(dense)) + 1.0 / (RRF_K + _raenge(bm25))
    elif methode in ("graph", "hybrid_kg"):
        # V2: Konzept-Wissensgraph (HippoRAG-Prinzip, Gutiérrez et al. 2024), siehe
        # wissensgraph.py. Chunks ohne Graph-Bezug (Score 0) erhalten KEINEN RRF-Beitrag —
        # findet der Graph nichts, ist "hybrid_kg" damit identisch zu "hybrid" (V1).
        import wissensgraph
        graph = wissensgraph.graph_scores(frage, chunks, frage_embedding=frage_embedding[0])
        if methode == "graph":
            rangwert = graph + 1e-6 * dense  # dense nur als Gleichstands-Auflösung
        else:
            bm25 = np.asarray(_bm25_index(chunks).get_scores(tokenisiere(frage)), dtype=np.float64)
            graph_rrf = np.where(graph > 0, 1.0 / (RRF_K + _raenge(graph)), 0.0)
            rangwert = (1.0 / (RRF_K + _raenge(dense)) + 1.0 / (RRF_K + _raenge(bm25))
                        + KG_GEWICHT * graph_rrf)
    else:
        raise ValueError(f"Unbekannte Retrieval-Methode: {methode!r} "
                         "(dense | bm25 | hybrid | graph | hybrid_kg, jeweils optional mit _rr)")

    ergebnisse = [
        {**chunk, "score": float(d), "rangwert": float(r)}
        for chunk, d, r in zip(chunks, dense, rangwert)
    ]
    ergebnisse.sort(key=lambda x: x["rangwert"], reverse=True)

    if rerank:
        # V3: die besten Kandidaten der Vorstufe per Cross-Encoder neu ordnen (reranker.py).
        # Neu bewertete Kandidaten stehen vorn (Reihenfolge = Reranker-Wert), alle übrigen
        # Chunks folgen in der Reihenfolge der Vorstufe. "score" bleibt der dense-Kosinus
        # (Schwelle unverändert), der Reranker-Wert steht zusätzlich in "rerank_score".
        import reranker
        n = min(reranker.RERANK_KANDIDATEN, len(ergebnisse))
        kandidaten = ergebnisse[:n]
        werte = reranker.bewerte(frage, [c["text"] for c in kandidaten])
        for rang, (c, w) in enumerate(zip(kandidaten, werte), start=1):
            c["rerank_score"] = w
            c["rang_vorstufe"] = rang
        kandidaten.sort(key=lambda c: c["rerank_score"], reverse=True)
        ergebnisse = kandidaten + ergebnisse[n:]

    return ergebnisse[:top_k], ergebnisse


# =============================================================================
# Prompt & Generierung
# =============================================================================
def baue_prompt(frage, ausgewaehlte_chunks):
    """
    Nicht-abgestuftes Prompt-Design (direkte Antwort). Bleibt als einfachere
    Alternative verfügbar; für die Studien-App wird standardmäßig
    baue_scaffolding_prompt() genutzt (siehe dort).
    """
    kontext = "\n\n".join(
        f"[Quelle {c['id']} – {c['thema']}]: {c['text']}" for c in ausgewaehlte_chunks
    )
    return f"""Du bist ein Lernassistent für die technische und berufliche Bildung.
Beantworte die folgende Frage NUR auf Basis des gegebenen Kontexts.
Wenn der Kontext die Frage nicht ausreichend beantwortet, sage das ehrlich,
anstatt zu raten. Erkläre verständlich, auf dem Niveau von Auszubildenden.

Kontext:
{kontext}

Frage: {frage}

Antwort:"""


# =============================================================================
# Pädagogisches Scaffolding
# =============================================================================
# V4 (S2-v1, 12 Oct 2026): ZWEI Stufen statt drei — Hinweis -> Lösung mit kurzer
# Begründung. Dazwischen kann die/der Lernende eine eigene Idee eingeben und
# bekommt eine Rückmeldung (ideen_feedback.py). Die frühere Erklärungs-Stufe
# entfällt: Erklärung und Lösung waren in V3 weitgehend redundant (Median 48 vs.
# 42 Wörter; die Erklärung nannte oft schon das Ergebnis), und die Ideen-Rückmeldung
# übernimmt die Zwischenstufe ("targeted feedback", Zourlidou et al. 2026).
# Einordnung (van de Pol et al. 2010, via Chen et al. 2026): Hinweis = hinting,
# Rückmeldung = feedback, Lösung = explaining + modeling.
# Zusätzlich die Hinweis-Regeln H1–H3 aus claude/Scaffolding_Spezifikation.md:
#   H1 Antwort nicht verraten (Jangra et al. 2025; MRBench "Revealing Answer"),
#   H2 Begriff / Größe / nächsten Denkschritt nennen (Zourlidou-Stufe 1),
#   H3 nicht auf den Kontext verweisen — die/der Lernende sieht ihn nicht
#      (V3-Basislinie: 5 von 21 Hinweisen sagten "Suchen Sie im Kontext ...").
# Feste Längenvorgabe ("3-4 Sätze") entfällt.
# Verweigerung: Formulierung "Die Lernmaterialien enthalten ... keine ..." wird vom
# Verweigerungs-Detektor v2 (ragas_auswertung.py) erkannt.
#
# Die alte 3-Stufen-Version (S3-v0, V0–V3) bleibt für Reproduzierbarkeit wählbar:
# SCAFFOLDING_VERSION = "S3-v0".
#
# Quellen der Grundstruktur:
#   - Happe et al. (2025): Hints/Explanations/Solutions als getaggte Abschnitte,
#     dort von Kursautor:innen vorautoriert statt LLM-generiert.
#   - Modran (2025): steuerbares hinting_level; unser Stufenmodell ist eine
#     vereinfachte, nicht-kontinuierliche Variante.
#   - Neagu et al. (2026): Lernende umgehen Scaffolding oft -> protokolliert wird,
#     wie weit Proband:innen die Stufen tatsächlich öffnen
#     (protokolliere_interaktion, Feld "scaffolding_stufe_erreicht").
#
# V5 (S2-v2, 13 Oct 2026): Der Hinweis wird in einem ZWEITEN, lösungs-kundigen Aufruf
# neu erzeugt (Hinweis-Prompt H-v3, siehe baue_hinweis_prompt). Aufruf 1 ist
# byte-identisch zu S2-v1 -> die Lösung ist bei T=0/seed 42 dieselbe wie in V4, der
# Vergleich V4 vs. V5 ändert also NUR den Hinweis (eine Änderung pro Version).
# Grund: in V4 verriet der Hinweis trotz Regeln H1–H3 weiterhin oft die Antwort
# (manuelle Vorbewertung, 22 Fragen: 6 Teil-Leck + 4 volles Leck). Ein Modell, das den
# Hinweis gleichzeitig mit der Lösung schreibt, "weiß" nicht explizit, was es nicht
# verraten darf. Muster übernommen aus ideen_feedback.py (IF-v1): sieht die Lösung,
# verdecktes Überlegungsfeld vor der Ausgabe.
#
# V6 (G-v1, 13 Oct 2026): fester, domänenunabhängiger Prompt-Satz (claude/Prompt_Set_Spezifikation.md).
# EIN Aufruf: STATUS -> LÖSUNG -> verdeckte ÜBERLEGUNG -> HINWEIS. Die Lösung wird zuerst geschrieben,
# damit der Hinweis "answer-aware" ist (Bhaskar & Hamouda 2025; Petukhova et al. 2026); die
# Überlegung davor senkt das Verraten (Zhao, Knežević & Käser 2026). STATUS ersetzt den
# Verweigerungs-Detektor (Regex) und erlaubt Teilantworten (Gala et al. 2026; Oche et al. 2025).
# Keine Beispiele, keine Fachwörter, keine dokumentspezifischen Hinweise (P1).
#
# V8 (G-v2, 14 Oct 2026): nur die Hinweis-Regeln geändert (L-Regeln, Status und Format wie G-v1).
# Anlass (manuelle Tests 14 Oct 2026, Fischer v7b): Hinweise forderten in 4 von 4 Nachschlage-
# fragen auf, eine Tabelle/Abbildung/den Text anzusehen ("Schau dir die Tabelle an"), obwohl
# Lernende nur die Frage sehen. H3 nennt das jetzt ausdrücklich; H6 gibt für reine Nachschlage-
# fragen eine Alternative (Bedeutung statt Wert). Weiterhin keine Beispiele, nichts Dokumentspezifisches.
SCAFFOLDING_VERSION = "G-v2"
STATUS_WERTE = ("BEANTWORTET", "TEILWEISE", "NICHT_IM_MATERIAL")
SCAFFOLDING_MARKER_VERSIONEN = {
    "S3-v0": {"hinweis": "STUFE1_HINWEIS:", "erklaerung": "STUFE2_ERKLAERUNG:", "loesung": "STUFE3_LOESUNG:"},
    "S2-v1": {"hinweis": "STUFE1_HINWEIS:", "loesung": "STUFE2_LOESUNG:"},
    "S2-v2": {"hinweis": "STUFE1_HINWEIS:", "loesung": "STUFE2_LOESUNG:"},  # Aufruf 1 = S2-v1
    "G-v1": {"hinweis": "HINWEIS:", "loesung": "LÖSUNG:"},  # Stufen für App/Batch: Hinweis, Lösung
    "G-v2": {"hinweis": "HINWEIS:", "loesung": "LÖSUNG:"},
}


def ist_g_version(version=None):
    """True für den festen Prompt-Satz ab V6 (G-v1, G-v2, …): STATUS-Feld, ein Aufruf, parse_g_v1."""
    return (version or SCAFFOLDING_VERSION).startswith("G-")


# Verweis auf Material, das Lernende nicht sehen (H3). Gemeinsam genutzt von stufen_check.py,
# retrieval_erklaeren.py und ideen_feedback.py (nur Protokoll, kein Eingriff).
MATERIAL_VERWEIS = re.compile(
    r"\b(kontext\w*|textstelle\w*|im text|im lernmaterial|lernmaterial\w*|im material|im buch|lehrbuch\w*|"
    r"abschnitt\w*|quelle\w*|textausschnitt\w*|tabelle\w*|liste\b|übersicht\w*|aufstellung\w*|"
    r"abbildung\w*|abb\.|diagramm\w*|schaubild\w*|grafik\w*|nachschl\w*|nachzuschl\w*|nachsehen|"
    r"schau dir [^.?!]{0,60}?\ban\b|tabellar\w*|wo (?:du|man) [^.?!]{0,60}?\bfinde\w*)", re.I)
# 14 Oct 2026 (V8d): "tabellarisch" und "wo du … findest" ergänzt (Hinweis "Überlege, wo du solche
# tabellarischen Werte findest" wurde vorher nicht erkannt).


def verweist_auf_material(text):
    """Liste der Fundstellen (leer = kein Verweis)."""
    return [m.group(0) for m in MATERIAL_VERWEIS.finditer(text or "")]


# Hinweis-Prüfung HP-v1 (14 Oct 2026, ab V8). Anlass: Auch mit G-v2 verwies der Hinweis bei
# Nachschlagefragen auf eine Tabelle ("in der Übersicht über die Stoffkonstanten schauen"), weil
# der Kontext stärker zieht als die Regel H3. Deshalb eine Prüfung NACH der Generierung:
#   ok            Hinweis ohne Materialverweis, unverändert
#   nachgebessert Verweis gefunden -> EIN zusätzlicher Aufruf schreibt nur den Hinweis neu
#   ersetzt       auch der neue Hinweis verweist auf Material oder verrät eine Zahl -> fester Ersatztext
# Nur bei STATUS BEANTWORTET/TEILWEISE (sonst gibt es keinen Hinweis). Der ursprüngliche Hinweis
# wird protokolliert (Spalte hinweis_original), damit sich Wirkung und Häufigkeit messen lassen.
HINWEIS_PRUEFUNG_VERSION = "HP-v2"   # None = Prüfung aus (Reproduktion von V6/V7)
# HP-v2 (14 Oct 2026): Der neu geschriebene Hinweis von HP-v1 erfand aus "Grundwissen" eine falsche
# Größenordnung ("wenige Zehntel Ohm pro Meter" statt 0,02857 Ω·mm²/m), und die Rückmeldungen bauten
# darauf auf. Deshalb: (1) Neuschreib-Prompt ohne Grundwissen als Faktenquelle und ohne Zahlen,
# Bereiche, Größenordnungen oder Einheiten; (2) zusätzliche Prüfung auf Wertangaben (Ziffern, die
# nicht in der Frage stehen, und Größenordnungswörter), für den ursprünglichen UND den neuen Hinweis.
HINWEIS_ERSATZ = ("Für diese Frage habe ich keinen Hinweis, der ohne das Lernmaterial auskommt. "
                  "Überlege kurz, was du schon über das Thema weißt, und öffne dann die Lösung.")
_ZAHL = re.compile(r"\d+(?:[.,]\d+)?")


def _zahlen(text):
    return {z.replace(",", ".") for z in _ZAHL.findall(text or "")}


WERTANGABE = re.compile(
    r"\b(zehntel|hundertstel|tausendstel|millionstel|größenordnung\w*|grössenordnung\w*|"
    r"im bereich (?:von|zwischen)|zwischen \d|einstellig\w*|zweistellig\w*|dreistellig\w*|"
    r"näher an der (?:unteren|oberen) grenze|(?:unteren|oberen) grenze)\b", re.I)  # "Prozent" allein ist keine Wertangabe
# V8d: einstellig/zweistellig/… und "untere/obere Grenze" ergänzt (Rückmeldungen: "im einstelligen
# Prozentbereich", "näher an der unteren Grenze").


def hinweis_hat_wertangabe(frage, hinweis):
    """Fundstellen für Wertangaben im Hinweis: Größenordnungswörter oder Zahlen, die nicht in der Frage
    stehen (Zahlen aus der Frage zu wiederholen ist erlaubt). Leer = keine Wertangabe."""
    funde = [m.group(0) for m in WERTANGABE.finditer(hinweis or "")]
    funde += sorted(_zahlen(hinweis) - _zahlen(frage))
    return funde


def hinweis_verraet_zahl(frage, hinweis, loesung):
    """Zahlen im Hinweis, die in der Lösung, aber nicht in der Frage stehen (wie stufen_check.zahlen_leck)."""
    return sorted((_zahlen(hinweis) & _zahlen(loesung)) - _zahlen(frage))


def _prompt_hinweis_neu(frage, loesung, alter_hinweis):
    """HP-v2: kein Grundwissen als Faktenquelle, keine Werte (siehe HINWEIS_PRUEFUNG_VERSION)."""
    return f"""Ein Hinweis für eine lernende Person ist unbrauchbar: Er verweist auf Material, das sie nicht hat,
oder er nennt Werte. Die Person sieht nur die Frage.

Schreibe einen neuen Hinweis:
- Lenke auf den Begriff, die Bedeutung der gesuchten Größe, wovon sie abhängt oder auf den nächsten
  Denkschritt, den die Frage verlangt.
- Nenne keine Zahlen, keine Bereiche, keine Größenordnungen und keine Einheiten.
- Nenne keine Fakten, die nicht in der Frage oder in der Lösung stehen.
- Verrate die Lösung nicht und fordere nicht auf, etwas anzusehen oder nachzuschlagen.
- Ein bis zwei kurze Sätze, sprich die Person mit „du" an.

### Frage
{frage}

### Lösung (geheim)
{loesung}

### Bisheriger Hinweis (nicht verwenden)
{alter_hinweis}

Antworte genau in diesem Format:
HINWEIS: <neuer Hinweis>"""


def hinweis_pruefen(frage, stufen):
    """Prüft und repariert den Hinweis in stufen (dict von parse_g_v1) an Ort und Stelle.
    Ergänzt stufen um hinweis_pruefung (ok | nachgebessert | ersetzt | "") und hinweis_original."""
    stufen.setdefault("hinweis_pruefung", "")
    stufen.setdefault("hinweis_original", "")
    if not HINWEIS_PRUEFUNG_VERSION or not ist_g_version() or SCAFFOLDING_VERSION == "G-v1":
        return stufen  # G-v1 (V6/V7) bleibt ohne Prüfung reproduzierbar
    hinweis = (stufen.get("hinweis") or "").strip()
    if stufen.get("status") not in ("BEANTWORTET", "TEILWEISE") or not hinweis:
        return stufen
    def sauber(h):
        if verweist_auf_material(h) or hinweis_verraet_zahl(frage, h, stufen.get("loesung", "")):
            return False
        return HINWEIS_PRUEFUNG_VERSION == "HP-v1" or not hinweis_hat_wertangabe(frage, h)

    if sauber(hinweis):
        stufen["hinweis_pruefung"] = "ok"
        return stufen
    stufen["hinweis_original"] = hinweis
    neu = ""
    try:
        roh = frage_llm(_prompt_hinweis_neu(frage, stufen.get("loesung", ""), hinweis), options=GENERIERUNGS_OPTIONEN)
        m = re.search(r"(?is)HINWEIS\s*:\s*(.+)", roh)
        neu = (m.group(1) if m else roh).strip().strip('"„“').strip()
    except Exception as e:  # Hinweis-Prüfung darf die Antwort nie verhindern
        print(f"WARNUNG Hinweis-Prüfung: {e}")
    if neu and sauber(neu):
        stufen["hinweis"], stufen["hinweis_pruefung"] = neu, "nachgebessert"
    else:
        stufen["hinweis"], stufen["hinweis_pruefung"] = HINWEIS_ERSATZ, "ersetzt"
    return stufen
HINWEIS_PROMPT_VERSION = "H-v3"  # nur bei S2-v2 genutzt


def scaffolding_marker():
    return SCAFFOLDING_MARKER_VERSIONEN[SCAFFOLDING_VERSION]


def _kontext_text(ausgewaehlte_chunks):
    return "\n\n".join(
        f"[Quelle {c['id']} – {c['thema']}]: {c['text']}" for c in ausgewaehlte_chunks
    )


def _prompt_s3_v0(frage, ausgewaehlte_chunks):
    """V0–V3: drei Stufen (unverändert, für Reproduzierbarkeit)."""
    m = SCAFFOLDING_MARKER_VERSIONEN["S3-v0"]
    return f"""Du bist ein Lernassistent für die technische und berufliche Bildung.
Beantworte die folgende Frage NUR auf Basis des gegebenen Kontexts, in DREI
aufeinander aufbauenden Stufen. Wenn der Kontext die Frage nicht ausreichend
beantwortet, sage das ehrlich in allen drei Stufen, anstatt zu raten.

{m['hinweis']} Ein kurzer Hinweis (1-2 Sätze), der in die
richtige Richtung lenkt, OHNE die Antwort direkt zu verraten. Soll zum
eigenen Nachdenken anregen.

{m['erklaerung']} Eine ausführlichere Erklärung des
relevanten Konzepts aus dem Kontext (3-4 Sätze), die der Antwort schon
näherkommt, aber noch nicht die vollständige, direkte Antwort ist.

{m['loesung']} Die vollständige, direkte Antwort auf die
Frage, verständlich auf dem Niveau von Auszubildenden erklärt.

Halte dich EXAKT an dieses Format mit allen drei Markern.

Kontext:
{_kontext_text(ausgewaehlte_chunks)}

Frage: {frage}"""


def _prompt_s2_v1(frage, ausgewaehlte_chunks):
    """V4: zwei Stufen + Hinweis-Regeln H1–H3 (siehe Modulkommentar)."""
    m = SCAFFOLDING_MARKER_VERSIONEN["S2-v1"]
    return f"""Du bist ein Lernassistent für Auszubildende in technischen Berufen.
Beantworte die folgende Frage NUR auf Basis des gegebenen Kontexts, in ZWEI Stufen.

Wichtig: Die/der Auszubildende sieht den Kontext NICHT. Schreibe deshalb nie
„im Kontext", „im Text", „in der Quelle" oder „suche nach dem Abschnitt".

{m['hinweis']} Ein Denkanstoß in 1-2 Sätzen, der in die richtige Richtung lenkt:
- Nenne den Begriff, die Größe oder den nächsten Denkschritt, um den es geht.
- Verrate die Antwort NICHT: kein Ergebnis, kein Zahlenwert, keine Formel und
  nicht die gesuchte Kernaussage.
- Du darfst mit einer Frage an die/den Auszubildende:n enden.

{m['loesung']} Die vollständige Antwort mit kurzer Begründung, verständlich für
Auszubildende:
- Zuerst die Antwort, dann warum. Begründe nur mit Zusammenhängen aus dem Kontext.
- Bei Rechnungen: Formel, Rechenweg mit Zahlen und Ergebnis.
- Kein Widerspruch zum Hinweis.

Wenn der Kontext die Frage nicht ausreichend beantwortet, rate nicht. Schreibe dann
in beiden Stufen ehrlich, dass die Lernmaterialien dazu keine ausreichende Antwort
enthalten.

Sprich die/den Auszubildende:n mit „du" an. Halte dich EXAKT an dieses Format mit
beiden Markern.

Kontext:
{_kontext_text(ausgewaehlte_chunks)}

Frage: {frage}"""


def _material_text(ausgewaehlte_chunks):
    """G-v1: nur die Texte, ohne IDs und Kapitelüberschriften (Kapitelzuordnung ist teils
    fehlerhaft). Allgemeine, dokumentunabhängige Bereinigung: Unicode-Normalisierung (Ligaturen),
    Silbentrennung am Zeilenende zusammenführen, Leerraum vereinheitlichen."""
    import unicodedata
    teile = []
    for c in ausgewaehlte_chunks:
        t = unicodedata.normalize("NFKC", c["text"])  # Ligaturen ("ﬂ" -> "fl"), allgemein
        t = re.sub(r"(\w)-\s*\n\s*(\w)", r"\1\2", t)
        teile.append(re.sub(r"\s+", " ", t).strip())
    return "\n\n".join(teile)


_HINWEIS_REGELN = {
    "G-v1": """Regeln für den Hinweis (die lernende Person sieht nur die Frage, nicht das Lernmaterial und nicht
die Lösung):
H1 Verrate die Lösung nicht, auch nicht mit anderen Worten.
H2 Lenke auf den Begriff, die Größe oder den nächsten Denkschritt, der zur Lösung führt.
H3 Verweise nur auf die Frage und auf Grundwissen, nie auf das Lernmaterial.
H4 Rege zum Nachdenken über einen Zusammenhang an, ohne zu überfordern.
H5 Ein bis zwei kurze Sätze, sprich die lernende Person mit „du" an; du darfst mit einer Frage enden.""",
    "G-v2": """Regeln für den Hinweis (die lernende Person sieht nur die Frage, nicht das Lernmaterial und nicht
die Lösung):
H1 Verrate die Lösung nicht, auch nicht mit anderen Worten.
H2 Lenke auf den Begriff, die Größe oder den nächsten Denkschritt, der zur Lösung führt.
H3 Die lernende Person sieht nur die Frage. Sie hat kein Lernmaterial, keine Tabelle, keine Abbildung
   und keinen Text vor sich. Fordere sie nie auf, etwas anzusehen oder nachzuschlagen.
H4 Rege zum Nachdenken über einen Zusammenhang an, ohne zu überfordern.
H5 Ein bis zwei kurze Sätze, sprich die lernende Person mit „du" an; du darfst mit einer Frage enden.
H6 Ist die Antwort ein einzelner Wert oder Begriff zum Nachschlagen, lenke auf das Verständnis dahinter:
   was die Größe bedeutet oder wovon sie abhängt, ohne den Wert zu nennen.""",
}
_HINWEIS_REGELNUMMERN = {"G-v1": "H1 bis H5", "G-v2": "H1 bis H6"}


def _prompt_g(version, frage, ausgewaehlte_chunks):
    """Fester Prompt-Satz G1 (Spezifikation §4.1). Regeln L1–L4, Status, Hinweis-Regeln je Version."""
    return f"""Du bist ein Lernassistent für Auszubildende. Du beantwortest eine Frage ausschließlich mit dem
Lernmaterial unten und bereitest dazu einen Denkanstoß vor.

Regeln für die Lösung:
L1 Nutze nur Aussagen, die im Lernmaterial stehen oder direkt daraus folgen. Ergänze kein eigenes
   Wissen, auch keine zusätzlichen Begründungen.
L2 Nenne zuerst die Antwort, dann kurz die Begründung aus dem Lernmaterial.
L3 Bei einer Rechnung: Formel, eingesetzte Werte und Ergebnis mit Einheit.
L4 Schreibe verständlich für Auszubildende.

Status:
- BEANTWORTET: Das Lernmaterial beantwortet die Frage.
- TEILWEISE: Das Lernmaterial beantwortet nur einen Teil. Beantworte diesen Teil und nenne, was fehlt.
- NICHT_IM_MATERIAL: Das Lernmaterial beantwortet die Frage nicht. Rate nicht.

{_HINWEIS_REGELN[version]}

### Lernmaterial
{_material_text(ausgewaehlte_chunks)}

### Frage
{frage}

Antworte genau in diesem Format:
STATUS: BEANTWORTET oder TEILWEISE oder NICHT_IM_MATERIAL
LÖSUNG: <Lösung nach L1 bis L4; bei NICHT_IM_MATERIAL ein Satz, dass das Lernmaterial dazu nichts enthält>
ÜBERLEGUNG: <nur für dich: welche Kernaussage der Lösung darf der Hinweis nicht verraten, und welcher Denkschritt führt dorthin?>
HINWEIS: <Hinweis nach {_HINWEIS_REGELNUMMERN[version]}; bei NICHT_IM_MATERIAL: –>"""


def _prompt_g_v1(frage, ausgewaehlte_chunks):
    """V6: G-v1 (unverändert, für Reproduktion von V6/V7)."""
    return _prompt_g("G-v1", frage, ausgewaehlte_chunks)


def _prompt_g_v2(frage, ausgewaehlte_chunks):
    """V8: G-v2 = G-v1 mit neuer H3 und H6 (siehe Kommentar bei SCAFFOLDING_VERSION)."""
    return _prompt_g("G-v2", frage, ausgewaehlte_chunks)


_G_FELD = re.compile(r"(?im)^[^\w\n]*(STATUS|L(?:Ö|OE)SUNG|(?:Ü|UE)BERLEGUNG|HINWEIS)[^\w\n]*:")
_G_SCHLUESSEL = {"STATUS": "status", "LÖSUNG": "loesung", "LOESUNG": "loesung",
                 "ÜBERLEGUNG": "ueberlegung", "UEBERLEGUNG": "ueberlegung", "HINWEIS": "hinweis"}


def parse_g_v1(rohtext):
    """Zerlegt die G-v1-Antwort (Spezifikation §4.1, Parsing und Fallback).
    Rückgabe hat dieselben Schlüssel wie parse_scaffolding_antwort plus status,
    hinweis_ueberlegung und format_fehler."""
    treffer = list(_G_FELD.finditer(rohtext))
    felder = {"status": "", "loesung": "", "ueberlegung": "", "hinweis": ""}
    for i, m in enumerate(treffer):
        name = _G_SCHLUESSEL[m.group(1).upper()]
        ende = treffer[i + 1].start() if i + 1 < len(treffer) else len(rohtext)
        if not felder[name]:  # erstes Vorkommen gilt
            felder[name] = rohtext[m.end():ende].strip().strip("*").strip()
    status_roh = re.sub(r"[^A-ZÄÖÜ]", "", felder["status"].upper())
    status = ("NICHT_IM_MATERIAL" if status_roh.startswith("NICHT") else
              "TEILWEISE" if status_roh.startswith("TEILWEISE") else
              "BEANTWORTET" if status_roh.startswith("BEANTWORTET") else "")
    format_fehler = []
    if not status:
        format_fehler.append("status")
        status = "BEANTWORTET"
    loesung = felder["loesung"]
    if not loesung:
        format_fehler.append("loesung")
        loesung = _G_FELD.sub("", rohtext).strip()
    hinweis = felder["hinweis"]
    if hinweis.strip(" –-—.") == "":
        hinweis = ""
        if status != "NICHT_IM_MATERIAL":
            format_fehler.append("hinweis")
    if status == "NICHT_IM_MATERIAL":
        hinweis = ""
    return {
        "hinweis": hinweis, "erklaerung": "", "loesung": loesung,
        # App: ohne Hinweis direkt die Lösung zeigen (bei NICHT_IM_MATERIAL kein Ideen-Feld)
        "vollstaendig_geparst": bool(hinweis) and "loesung" not in format_fehler,
        "status": status, "hinweis_ueberlegung": felder["ueberlegung"],
        "format_fehler": ",".join(format_fehler),
    }


_PROMPTS = {"S3-v0": _prompt_s3_v0, "S2-v1": _prompt_s2_v1, "S2-v2": _prompt_s2_v1, "G-v1": _prompt_g_v1,
            "G-v2": _prompt_g_v2}


def baue_hinweis_prompt(frage, ausgewaehlte_chunks, loesung):
    """V5 (S2-v2), Hinweis-Prompt H-v3: eigener Aufruf, der die Lösung kennt.
    Regeln H1–H5 aus claude/Scaffolding_Spezifikation.md §3.1 (Jangra et al. 2025,
    Abschnitt 4.1; Zourlidou et al. 2026; Wood et al. 1976)."""
    return f"""Du schreibst einen Hinweis (Denkanstoß) für Auszubildende in technischen Berufen.
Du kennst die Frage, die Lernmaterialien und die richtige Lösung. Die/der Auszubildende
sieht NUR die Frage, nicht die Lernmaterialien und nicht die Lösung.

Regeln für den Hinweis:
H1 Verrate die Lösung nicht: kein Ergebnis, kein Zahlenwert aus der Lösung, keine Formel
   mit eingesetzten Werten, nicht die gesuchte Kernaussage, Aufzählung oder Benennung.
H2 Zeige die Richtung: nenne den Begriff, die Größe oder den nächsten Denkschritt, der
   zur Lösung führt.
H3 Nutze nur, was die/der Auszubildende kennt: die Frage und Grundwissen. Schreibe nie
   „im Kontext", „im Text", „in der Tabelle", „in der Quelle" oder „in den Materialien".
H4 Fördere Verständnis: lenke auf den Zusammenhang (wie hängt was zusammen, warum),
   nicht nur auf ein einzelnes Stichwort, aber überfordere nicht.
H5 Klar und kurz: 1-2 Sätze, sprich die/den Auszubildende:n mit „du" an, du darfst mit
   einer Frage enden.

Lernmaterialien:
{_kontext_text(ausgewaehlte_chunks)}

Frage: {frage}

Lösung (GEHEIM, nicht verraten):
{loesung}

Antworte GENAU in diesem Format:
UEBERLEGUNG: <nur für dich: (a) Welche Wörter und Zahlen aus der Lösung dürfen NICHT im Hinweis stehen? (b) Welcher Denkschritt führt dorthin?>
HINWEIS: <der Hinweis>"""


_HINWEIS_FELD = re.compile(r"(?:^|\n)\W*HINWEIS\W*:", re.IGNORECASE)
_UEBERLEGUNG_FELD = re.compile(r"\b(?:UEBERLEGUNG|ÜBERLEGUNG)\s*:", re.IGNORECASE)


def parse_hinweis(rohtext):
    """Gibt (hinweis, ueberlegung) zurück; hinweis = "" wenn das Format fehlt
    (dann bleibt der Hinweis aus Aufruf 1, siehe beantworte_frage)."""
    treffer = list(_HINWEIS_FELD.finditer(rohtext))
    if not treffer:
        return "", rohtext.strip()
    letzter = treffer[-1]
    hinweis = rohtext[letzter.end():].strip().strip("*").strip()
    m = _UEBERLEGUNG_FELD.search(rohtext[:letzter.start()])
    ueberlegung = rohtext[m.end():letzter.start()].strip() if m else ""
    return hinweis, ueberlegung


def baue_scaffolding_prompt(frage, ausgewaehlte_chunks):
    """Prompt der aktuellen SCAFFOLDING_VERSION (siehe Modulkommentar oben)."""
    return _PROMPTS[SCAFFOLDING_VERSION](frage, ausgewaehlte_chunks)


def parse_scaffolding_antwort(rohtext):
    """
    Zerlegt die gestufte Rohantwort in die einzelnen Stufen (Marker der aktuellen
    SCAFFOLDING_VERSION). Bewusst als reine, vom LLM-Aufruf getrennte Funktion,
    damit sie ohne Modell getestet werden kann.

    Rückgabe hat immer die Schlüssel hinweis / erklaerung / loesung (bei S2-v1 ist
    erklaerung leer), damit das Format von interaktionen.csv und alle
    Auswertungsskripte unverändert bleiben.

    Fallback: Fehlt ein Marker (LLMs halten Formatvorgaben nicht immer exakt ein),
    wird der GESAMTE Rohtext als 'loesung' verwendet und der Rest leer gelassen —
    die Studien-App zeigt dann direkt die volle Antwort.
    """
    marker = scaffolding_marker()
    marker_positionen = {}
    for stufe, m in marker.items():
        pos = rohtext.find(m)
        if pos != -1:
            marker_positionen[stufe] = pos

    if len(marker_positionen) < len(marker):
        return {"hinweis": "", "erklaerung": "", "loesung": rohtext.strip(), "vollstaendig_geparst": False}

    sortiert = sorted(marker_positionen.items(), key=lambda x: x[1])
    ergebnis = {"hinweis": "", "erklaerung": "", "loesung": "", "vollstaendig_geparst": True}
    for i, (stufe, pos) in enumerate(sortiert):
        start = pos + len(marker[stufe])
        ende = sortiert[i + 1][1] if i + 1 < len(sortiert) else len(rohtext)
        ergebnis[stufe] = rohtext[start:ende].strip()

    return ergebnis


def frage_llm(prompt, model=MODEL_NAME, options=None):
    """think=False: unterdrückt Qwen3.5s sichtbare Reasoning-Kette, damit
    Proband:innen eine direkte, nicht durch Zwischenschritte verlängerte
    Antwort erhalten (relevant für Antwortzeit als Usability-Faktor,
    vgl. Perceived Ease of Use im TAM, Davis 1989).

    options: optionale Ollama-Parameter (z. B. {"temperature": 0, "seed": 42}).
    Wird von der Studien-App NICHT gesetzt (unverändertes Verhalten), aber von
    ragas_auswertung.py genutzt, damit die LLM-als-Richter-Bewertung
    reproduzierbar ist."""
    payload = {"model": model, "prompt": prompt, "stream": False, "think": False}
    if options:
        payload["options"] = options
    response = requests.post(OLLAMA_URL, json=payload, timeout=120)
    response.raise_for_status()
    return response.json()["response"].strip()


def sicherheitspruefung(text):
    text_klein = text.lower()
    treffer = [w for w in SICHERHEITS_SCHLUESSELWOERTER if w in text_klein]
    return (len(treffer) > 0), treffer


def _hinweis_separat(frage, top_chunks, stufen):
    """V5: zweiter Aufruf für den Hinweis. Kein zweiter Aufruf, wenn Aufruf 1 nicht
    geparst wurde oder die Lösung eine Verweigerung ist (dann gibt es nichts zu
    verbergen; der Hinweis aus Aufruf 1 bleibt). Rückgabe ergänzt Diagnosefelder,
    die NICHT in interaktionen.csv landen (Format unverändert), sondern nur im
    Batchlauf separat gespeichert werden (fuehre_testfragen_aus.py)."""
    zusatz = {"hinweis_aufruf1": stufen["hinweis"], "hinweis_ueberlegung": "",
              "hinweis_quelle": "aufruf1"}
    if not stufen["vollstaendig_geparst"]:
        return zusatz
    from ragas_auswertung import ist_modell_verweigerung  # lokal: vermeidet Zirkelimport
    if ist_modell_verweigerung(stufen["loesung"]):
        zusatz["hinweis_quelle"] = "aufruf1_verweigerung"
        return zusatz
    roh = frage_llm(baue_hinweis_prompt(frage, top_chunks, stufen["loesung"]),
                    options=GENERIERUNGS_OPTIONEN)
    hinweis, ueberlegung = parse_hinweis(roh)
    zusatz["hinweis_ueberlegung"] = ueberlegung
    if hinweis:
        zusatz["hinweis"] = hinweis
        zusatz["hinweis_quelle"] = "separat"
    else:
        zusatz["hinweis_quelle"] = "aufruf1_formatfehler"
    return zusatz


def beantworte_frage(frage, chunks, top_k=4, methode=None):
    """
    Vollständige Pipeline: Retrieval -> Schwellenwert-Prüfung -> gestufte
    Generierung (Scaffolding) -> Sicherheitsprüfung. Verweigerung statt
    Raten bei bester_score < Schwelle ist die zentrale Sicherheitsmaßnahme
    des Systems (Systemkonzept-Säule "Sicherheit"; siehe auch
    Grounding-Prinzip bei Lewis et al. 2020). Die dreistufige Antwort
    (Hinweis -> Lösung, ab V4; siehe SCAFFOLDING_VERSION) setzt die Säule "Lernunterstützung" um
    (siehe baue_scaffolding_prompt-Modulkommentar für Quellen).

    methode: Retrieval-Methode (None = RETRIEVAL_METHODE, siehe retrieval()).
    bester_score = höchste Kosinus-Ähnlichkeit über ALLE Chunks, unabhängig von
    der Methode — bei "dense" identisch zum bisherigen Verhalten, bei
    bm25/hybrid bleibt die Schwellenprüfung dadurch unverändert.
    """
    top_chunks, alle_chunks = retrieval(frage, chunks, top_k=top_k, methode=methode)
    bester_score = max((c["score"] for c in alle_chunks), default=0.0)
    genuegend_relevanz = bester_score >= RELEVANZ_SCHWELLE

    ergebnis = {
        "frage": frage,
        "bester_score": bester_score,
        "genuegend_relevanz": genuegend_relevanz,
        "top_chunks": top_chunks,
    }

    if not genuegend_relevanz:
        verweigerung = (
            "Dazu habe ich in den Lernmaterialien keine ausreichend passende "
            "Quelle gefunden und möchte deshalb keine geratene Antwort geben. "
            "Bitte wende dich an deine Lehrkraft oder formuliere die Frage genauer."
        )
        ergebnis["hinweis"] = ""
        ergebnis["erklaerung"] = ""
        ergebnis["loesung"] = verweigerung
        ergebnis["vollstaendig_geparst"] = False
        ergebnis["status"] = "GATE"
        ergebnis["quellen"] = []
        ergebnis["sicherheitshinweis"] = None
        return ergebnis

    prompt = baue_scaffolding_prompt(frage, top_chunks)
    rohantwort = frage_llm(prompt, options=GENERIERUNGS_OPTIONEN)
    stufen = parse_g_v1(rohantwort) if ist_g_version() else parse_scaffolding_antwort(rohantwort)
    ist_relevant, treffer = sicherheitspruefung(frage + " " + stufen["loesung"])

    if SCAFFOLDING_VERSION == "S2-v2":
        stufen.update(_hinweis_separat(frage, top_chunks, stufen))
    hinweis_pruefen(frage, stufen)  # ab V8 (HP-v1); ohne Wirkung bei älteren Versionen

    ergebnis.update(stufen)
    ergebnis["quellen"] = [{"id": c["id"], "thema": c["thema"]} for c in top_chunks]
    ergebnis["sicherheitshinweis"] = treffer if ist_relevant else None
    return ergebnis


# =============================================================================
# Evaluationsdaten: Interaktionsprotokoll
# =============================================================================
# Protokollierung von Nutzungsdaten (Frage, genutzte Quellen, Antwort,
# Sicherheitshinweis, Zeitstempel) ist im eigenen Forschungskonzept explizit
# als Datenquelle vorgesehen ("Interviews und Nutzungsdaten" im
# methodischen Vorgehen). Pseudonymisierte Sitzungs-ID statt Klarnamen
# entspricht Standardpraxis der Forschungsethik (DSGVO-konform) und dem
# in Design_Entscheidungen_Literatur.md dokumentierten Datenschutzprinzip.
INTERAKTIONS_FELDER = [
    "zeitstempel", "sitzungs_id", "frage", "bester_score",
    "genuegend_relevanz", "hinweis", "erklaerung", "loesung",
    "scaffolding_stufe_erreicht", "quellen", "sicherheitshinweis",
    "kb_hash", "status", "scaffolding_version",
    "hinweis_pruefung", "hinweis_original",  # ab V8 (HP-v1)
]


def _log_spalten_sicherstellen():
    """Ab V6 hat interaktionen.csv die Spalten status und scaffolding_version, ab V8 zusätzlich
    hinweis_pruefung und hinweis_original. Ältere Logs werden einmalig umgeschrieben (alte Zeilen:
    neue Spalten leer); vorher Sicherungskopie."""
    if not INTERAKTIONS_LOG.exists():
        return
    with open(INTERAKTIONS_LOG, encoding="utf-8", newline="") as f:
        r = csv.DictReader(f)
        if r.fieldnames == INTERAKTIONS_FELDER:
            return
        zeilen = list(r)
    sicherung = INTERAKTIONS_LOG.with_name("interaktionen_vor_V6_sicherung.csv")
    if sicherung.exists():  # ab V8: jede weitere Spaltenänderung bekommt eine eigene Sicherung
        sicherung = INTERAKTIONS_LOG.with_name(
            f"interaktionen_vor_spalten_{datetime.datetime.now():%Y%m%d_%H%M%S}.csv")
    import shutil
    shutil.copy2(INTERAKTIONS_LOG, sicherung)
    with open(INTERAKTIONS_LOG, "w", encoding="utf-8", newline="") as f:
        w = csv.DictWriter(f, fieldnames=INTERAKTIONS_FELDER, restval="", extrasaction="ignore")
        w.writeheader()
        w.writerows(zeilen)
    print(f"interaktionen.csv auf neue Spalten umgestellt (Sicherung: {sicherung.name})")


def protokolliere_interaktion(sitzungs_id, ergebnis, scaffolding_stufe_erreicht=1):
    """
    scaffolding_stufe_erreicht: wie weit die/der Proband:in tatsächlich
    geklickt hat. Ab V4: 1 = nur Hinweis gesehen, 2 = + Lösung.
    V0–V3 (S3-v0): 1 = Hinweis, 2 = + Erklärung, 3 = + Lösung. Eigenes Uptake-Maß analog zu
    Neagu et al. (2026), die zeigen, dass Lernende angebotenes Scaffolding oft umgehen.
    Ab V6 zusätzlich: status (G-v1: BEANTWORTET / TEILWEISE / NICHT_IM_MATERIAL, GATE) und
    scaffolding_version.
    """
    _log_spalten_sicherstellen()
    neu = not INTERAKTIONS_LOG.exists()
    with open(INTERAKTIONS_LOG, "a", newline="", encoding="utf-8") as f:
        w = csv.DictWriter(f, fieldnames=INTERAKTIONS_FELDER)
        if neu:
            w.writeheader()
        w.writerow({
            "zeitstempel": datetime.datetime.now().isoformat(timespec="seconds"),
            "sitzungs_id": sitzungs_id,
            "frage": ergebnis["frage"],
            "bester_score": round(ergebnis["bester_score"], 4),
            "genuegend_relevanz": ergebnis["genuegend_relevanz"],
            "hinweis": ergebnis.get("hinweis", ""),
            "erklaerung": ergebnis.get("erklaerung", ""),
            "loesung": ergebnis.get("loesung", ""),
            "scaffolding_stufe_erreicht": scaffolding_stufe_erreicht,
            "quellen": "; ".join(q["id"] for q in ergebnis["quellen"]),
            "sicherheitshinweis": "; ".join(ergebnis["sicherheitshinweis"]) if ergebnis["sicherheitshinweis"] else "",
            "kb_hash": ergebnis.get("kb_hash", ""),
            "status": ergebnis.get("status", ""),
            "scaffolding_version": SCAFFOLDING_VERSION,
            "hinweis_pruefung": ergebnis.get("hinweis_pruefung", ""),
            "hinweis_original": ergebnis.get("hinweis_original", ""),
        })


# =============================================================================
# Evaluationsdaten: Fragebogen (Technology Acceptance Model)
# =============================================================================
# Das TAM (Technology Acceptance Model, Davis 1989, "Perceived Usefulness,
# Perceived Ease of Use, and User Acceptance of Information Technology",
# MIS Quarterly) ist DAS Standardinstrument zur Akzeptanzmessung von
# Informationssystemen und wird in genau diesem Anwendungsfeld bereits von
# Happe et al. (2025) für die Evaluation eines KI-Tutors eingesetzt
# (13 Teilnehmende, PU/PEOU/ITU auf 5-Punkte-Likert-Skala) — direktes
# methodisches Vorbild für dieses Instrument.
FRAGEBOGEN_ITEMS = [
    {"id": "PU1", "dimension": "Wahrgenommener Nutzen (Perceived Usefulness)",
     "text": "Der Lernassistent hat mir geholfen, die Lerninhalte besser zu verstehen."},
    {"id": "PU2", "dimension": "Wahrgenommener Nutzen (Perceived Usefulness)",
     "text": "Die Nutzung des Lernassistenten würde meine Lerneffizienz steigern."},
    {"id": "PEOU1", "dimension": "Wahrgenommene Benutzerfreundlichkeit (Perceived Ease of Use)",
     "text": "Die Bedienung des Lernassistenten war für mich einfach und klar."},
    {"id": "PEOU2", "dimension": "Wahrgenommene Benutzerfreundlichkeit (Perceived Ease of Use)",
     "text": "Es fiel mir leicht, passende Fragen an den Lernassistenten zu formulieren."},
    {"id": "TRUST1", "dimension": "Vertrauen (Trust)",
     "text": "Ich vertraue den Antworten des Lernassistenten."},
    {"id": "TRUST2", "dimension": "Vertrauen (Trust)",
     "text": "Es war für mich nachvollziehbar, woher eine Antwort stammt (Quellenangabe)."},
    {"id": "TRUST3", "dimension": "Vertrauen (Trust)",
     "text": "Ich fand es gut, dass der Assistent auch mal 'Ich weiß es nicht' sagt, statt zu raten."},
    # Scaffolding-Items: operationalisieren direkt die Systemkonzept-Säule
    # "Lernunterstützung" (Hinweis -> eigene Idee -> Lösung, ab V4). SCAFF2 misst
    # bewusst nicht nur Zustimmung, sondern das Bypass-Verhalten selbst
    # (vgl. Neagu et al. 2026, Instrumentelles vs. exekutives Hilfesuchen).
    {"id": "SCAFF1", "dimension": "Lernunterstützung / Scaffolding",
     "text": "Die schrittweise Hilfe (Hinweis → eigene Idee mit Rückmeldung → Lösung) hat mir beim eigenständigen Lernen geholfen."},
    {"id": "SCAFF2", "dimension": "Lernunterstützung / Scaffolding",
     "text": "Ich habe meistens versucht, erst mit dem Hinweis selbst weiterzukommen, bevor ich die volle Lösung angesehen habe."},
    {"id": "ITU1", "dimension": "Nutzungsabsicht (Intention to Use)",
     "text": "Ich würde diesen Lernassistenten auch zukünftig für mein Lernen nutzen wollen."},
]


def speichere_fragebogen(sitzungs_id, antworten):
    """antworten: dict {item_id: wert (1-5)}"""
    neu = not FRAGEBOGEN_LOG.exists()
    with open(FRAGEBOGEN_LOG, "a", newline="", encoding="utf-8") as f:
        writer = csv.writer(f)
        header = ["zeitstempel", "sitzungs_id"] + [item["id"] for item in FRAGEBOGEN_ITEMS]
        if neu:
            writer.writerow(header)
        zeile = [datetime.datetime.now().isoformat(timespec="seconds"), sitzungs_id]
        zeile += [antworten.get(item["id"], "") for item in FRAGEBOGEN_ITEMS]
        writer.writerow(zeile)